function v = anglevecsum(x,y,z)
% ANGLEVECSUM root sum of squares of (presumably) angle data
xyz = [x(:) y(:) z(:)]; % FIXME no error checking for input sizes, etc.
v = sqrt(sum(xyz.^2,2));