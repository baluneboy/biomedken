function [iFirstMoveInEEG,tOffsetEMG] = eevsynch(strSubject, strSession, strTask)
% eevsynch.m - synchs Vicon first motion to EEG and EMG sets
% 
% INPUTS
% strSubject - string, subject code
% strSession - string, 'pre' or 'post'
% strTask - string, name of task
% 
% OUTPUTS
% 
% 
% EXAMPLE
% strSubject = 'c1363plas';
% strSession = 'pre';
% strTask = 'supination_pronation';
% [iFirstMoveInEEG,tOffset] = eevsynch(strSubject, strSession, strTask);

% Author - Krisanne Litinas
% $Id: eevsynch.m 5749 2010-08-06 14:00:31Z klitinas $

%% Get needed data paths
if exist('s:\','dir')
    [strViconDir, strEEGDir, strEMGDir,~,strBaseDir] = geteevdirs(strSubject, strSession);
else % home PC or extHD
    strBaseDir = 'G:\data\upper\eeg_emg_vicon\c1363plas\pre';
    strEEGDir = fullfile(strBaseDir,'eeg');
    strEMGDir = fullfile(strBaseDir,'emg');
    strViconDir = 'G:\data\upper\vicon\dalyUE\upperControl\20091123_c1363plas';
end

%% Get skipped trials and any extraneous synch pulses in EEG and EMG streams
[skippedTrials, extraSynchs] = queryeevskippedtrials(strSubject,strTask,strSession);
% skippedTrials = [60 63];
% extraSynchs = [60 63];

%% Count number of 50ms pulses in Vicon CSV files
casViconFiles = getpatternfiles('.csv$',strViconDir,'cas');
%numPulsesInVicon = countviconsynchpulses(casViconFiles,skippedTrials);

%% Load and process EMG file
strFileEMG = geteevfiles(strEMGDir,strTask);
[evtEMG,fsEMG] = getemgevt(strFileEMG);
[indEMG,durEMG] = getleadingedgesdurations(evtEMG,0.1);

% Find 50 ms ["start" pulses]
indFiftyEMG = durEMG < 60;

iFiftyEMG = indEMG(indFiftyEMG);

%% Load and process EEG file
strFileEEG = geteevfiles(strEEGDir,strTask);
[evtEEG,fsEEG] = geteegevt(strFileEEG);
iFiftyEEG = eegevtparse(evtEEG);

%% Remove extraSynchs from iFiftyEEG and iFiftyEMG vectors if needed
%iFiftyEEG(extraSynchs) = [];
iFiftyEMG(extraSynchs) = [];

%% Compare length of EEG and EMG legitimate pulses and then with number of vicon pulses
% crosscheckpulses(iFiftyEEG,iFiftyEMG,numPulsesInVicon)

%% Compare EEG and EMG marks and get EMG relative to EEG offset in seconds [emgOne - eegOne]
emgOffset = guieevsynch(evtEEG,evtEMG,iFiftyEEG,iFiftyEMG,fsEEG,fsEMG);
tOffsetEMG = emgOffset / fsEEG;
iNewFiftyEEG = iFiftyEMG - emgOffset;
iNewFiftyEEG(skippedTrials) = [];

%% Read the index_first_move csv file
strFirstMoveCSV = fullfile(strBaseDir,'first_motion_index.csv');
cMoveInfo = eevloadfirstmoves(strFirstMoveCSV);

%% Get synching info of first motion
[movesToSynch,~,casMoves,numGoodTrials] = get_aggregate_vicon_to_synch(cMoveInfo,skippedTrials);

% Trim off rows for skipped trials or for header (line 1) line
iHeaderLineOrSkipped = isnan(numGoodTrials);
movesToSynch(iHeaderLineOrSkipped) = [];
casMoves(iHeaderLineOrSkipped) = [];

% iFirstMoveInEEG = iFiftyEEG + movesToSynch;
iFirstMoveInEEG = iNewFiftyEEG + movesToSynch;

tMoveInEEG = iFirstMoveInEEG / fsEEG;
tMoveInEMG = tMoveInEEG + tOffsetEMG;

%% Write .ev2 script files for Neuroscan and .s2s files for Spike [one each for pronated, one for supinated trials]
eev_gen_ev2(strBaseDir,tMoveInEEG,fsEEG,casMoves,'pro')
eev_gen_ev2(strBaseDir,tMoveInEEG,fsEEG,casMoves,'sup')

eev_gen_s2s(strBaseDir,tMoveInEMG,casMoves,tOffsetEMG,'pro')
eev_gen_s2s(strBaseDir,tMoveInEMG,casMoves,tOffsetEMG,'sup')
