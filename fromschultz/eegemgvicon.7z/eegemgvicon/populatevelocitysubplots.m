function H = populatevelocitysubplots(numPlotRows,numPlotCols,dydt,filtdydt,t,strPrefix,strDir,strTrial)
% populatevelocitysubplots.m
%
% NOTES
% Clunky and not elegant, should be fixed when time.
% 
% EXAMPLE
% strPrefix = 'trial';
% H = populatevelocitysubplots(5,2,dydt,filtdydt,t,strFigureName,'c:\temp','trial_1');

% Author: Krisanne Litinas
% $Id: populatevelocitysubplots.m 4627 2010-02-16 19:27:49Z klitinas $

% Grab any figure files [.pdf] and numbering that already exist
strFigurePattern = [strPrefix '\D*(?<num>\d{1,3})\.pdf$'];
casFigures = getpatternfiles(strFigurePattern,strDir,'cas');
casDotFigs = getpatternfiles([strPrefix '\D*(?<num>\d{1,3})\.fig$'],strDir,'cas');
if isempty(casFigures)
    trialNum = 1;
    dotFigNum = 1;
else
    [~,iSort] = sortcasfiles(casFigures,strPrefix);
    trialNum = iSort(end);
    [~,iDotFig] = sortcasfiles(casDotFigs,strPrefix);
    dotFigNum = iDotFig(end);
end
strFigure = fullfile(strDir,[strPrefix,'_',num2str(dotFigNum),'.fig']);
strPDF = strrep(strFigure,'.fig','.pdf');

% Load figure if it already exists
if ~exist(strPDF,'file') && exist(strFigure,'file')
    H = hgload(strFigure);
else % increment fig file num
    H = figure;
    if ~isempty(casFigures)
        strFigure = fullfile(strDir,[strPrefix,'_',num2str(trialNum+1),'.fig']);
        strPDF = strrep(strFigure,'.fig','.pdf');
    end
end

% Find number of subplots already populated
hExisting = findobj(H,'type','axes');
hLegExisting = findobj(H,'tag','legend');
existingPlots = setdiff(hExisting,hLegExisting);
numExistPlots = length(existingPlots);

% Want to populate next subplot
numNewPlot = numExistPlots + 1;
hSub = subplot(numPlotRows,numPlotCols,numNewPlot);

% Plot velocity and filtered velocity profiles
hDyDt = plot(t,dydt,'b');
hold on
hFilt = plot(t,filtdydt,'r');
yLabel = ylabel('Velocity (deg/sec)');
hTitle = title(strTrial);
set(hTitle,'interpreter','none');
set(hSub,'ylim',[-5 5])
set(hSub,'YTick',-5:1:5)
set(hSub,'YTicklabel',-5:1:5)

% add xlabel to bottom 2 plots
if numNewPlot > 8 % change this
    xLabel = xlabel('time (sec)');
end

% Save figure to .fig
hgsave(strFigure)

% Place legend after last subplot is created and save to pdf
numTotalPlots = numPlotRows*numPlotCols;
if numNewPlot == numTotalPlots
    hLegend = legend('Wheel velocity','Filtered wheel velocity','Location',[0.7547 0.0164 0.1492 0.0475]);
    set(H,'paperposition',[0.5 0.5 7.5 10])
    print(H,'-dpdf',strPDF)
end

close all


