function fileList = getdelayfile(strDir,strTask)
% getdelayfile - returns full filename of laptop delay .mat file
% 
% INPUTS
% strDir - string, directory name to look for delay file
% strTask - string, name of task
% 
% OUTPUTS
% fileList - string, full filename of laptop .mat file (if only one found)
% or cas, list of filenames of laptop .mats
% 
% EXAMPLE
% strDir = 'S:\data\upper\eeg_emg_vicon\c1363plas\pre\vis_stim';
% strDelayFile = getdelayfile(strDir);

% Author - Krisanne Litinas
% $Id$

% Plasticity task known as supination_pronation and wristTask
if strcmp(strTask,'supination_pronation')
    strTask = 'wristTask';
end

% Uses regular expressions to get list of mat files in directory
strPattern = ['.*' strTask '.*time_delay.*.mat'];
casDelayFiles = getpatternfiles(strPattern,strDir,'cas');
numDelayFiles = length(casDelayFiles);

if numDelayFiles == 1
    fileList = casDelayFiles{1};
else
    fileList = casDelayFiles;
end