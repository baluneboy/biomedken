function H = visualizevelocityalgorithm(strDir)
% testvelocityalgorithm.m
%
% INPUTS
% strDir = directory containing vicon csv files

casFiles = getpatternfiles('csv$',strDir,'cas');

for i = 1:length(casFiles)
    strFile = casFiles{i};
    strTrial = basename(strFile);
    s = viconasciiread(strFile,0);
    sTraj = mat2struct(s.trialData,s.casLabels);
    yAngleWheel = sTraj.yangleWheel;
    
    % parameters for filter
    order = 5;
    fc = 2;
    fs = 100;
    strFiltType = 'low';
    dydt = getdydt(yAngleWheel,fs);
    [dydtfilt,t] = filtdydt(yAngleWheel,order,fc,fs,strFiltType);
    
    % plot them
    strPrefix = 'supination_pronation';
    numPlotRows = 5;
    numPlotCols = 2;
    H = populatevelocitysubplots(numPlotRows,numPlotCols,dydt,dydtfilt,t,strPrefix,strDir,strTrial);
end

% Print last set of plots to pdf
hLegend = legend('Wheel velocity','Filtered wheel velocity','Location',[0.7547 0.0164 0.1492 0.0475]);
set(H,'paperposition',[0.5 0.5 7.5 10])
print(H,'-dpdf',fullfile(strDir,'supination_pronation_10.pdf'))