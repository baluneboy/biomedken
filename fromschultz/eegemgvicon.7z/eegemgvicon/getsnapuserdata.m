function ud = getsnapuserdata(t,ylim)
ud.xdata = t;
ymin = min(ylim);
ymax = max(ylim);
ycushion = 0.1*abs(ymax-ymin);
ud.ymin = ymin-ycushion;
ud.ymax = ymax+ycushion;