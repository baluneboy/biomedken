function crosscheckpulses(iFiftyEEG,iFiftyEMG,numPulsesInVicon)
% crosscheckpulses.m - does checking to make sure that number of event
% synchs pulses in EEG, EMG, and Vicon sets match
% 
% INPUTS
% iFiftyEEG - vector of indices of detected 50ms pulses in EEG stream
% iFiftyEMG - vector of indices of detected 50ms pulses in EMG stream
% numPulsesInVicon - vector of length numViconAsciiFiles, contains number
%   of 50ms pulses in each file
% 
% OUTPUTS
% none explicit, but throws errors if number of pulses do not match
% 
% EXAMPLE
% iFiftyEEG = [5 8 10];
% iFiftyEMG = [6 9 11];
% numPulsesInVicon = [nan; 1; 1; 1];
% crosscheckpulses(iFiftyEEG,iFiftyEMG,numPulsesInVicon)

% Author - Krisanne Litinas
% $Id$

fprintf('\nChecking number of pulses in EEG, EMG, and Vicon streams...\n')
numPulsesEEG = length(iFiftyEEG);
numPulsesEMG = length(iFiftyEMG);
numTotalViconPulses = nansum(numPulsesInVicon);

fprintf('Number of EEG pulses found: %d\n', numPulsesEEG);
fprintf('Number of EMG pulses found: %d\n', numPulsesEMG);
fprintf('Number of Vicon pulses found: %d\n', numTotalViconPulses);

% Errors out if pulse numbers are not equal
if numPulsesEEG ~= numPulsesEMG
    error('error:daly:eegemgvicon','Error: %d valid EEG pulses found, but %d EMG pulses found',numPulsesEEG,numPulsesEMG)
end
if numPulsesEEG ~= numTotalViconPulses
    error('error:daly:eegemgvicon','Error: %d valid EEG pulses found, but %d Vicon pulses found',numPulsesEEG,numTotalViconPulses)
end