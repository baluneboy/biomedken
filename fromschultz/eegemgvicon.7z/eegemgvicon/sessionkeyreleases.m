function keyReleases = sessionkeyreleases(strSubject,strTask,strSession)
% EXAMPLE
% strSubject = 'c1320plas';
% strTask = 'supination_pronation';
% strSession = 'pre';
% keyReleases = sessionkeyreleases(strSubject,strTask,strSession);

% Rsync from nightly_mirror
eevrsynctodatapath(strSubject,strSession)

% Get Vicon path and skipped trials
[strViconDir, ignoreOne, ignoreTwo,ignoreThree,strBaseDir] = geteevdirs(strSubject, strSession);

if ~exist(strBaseDir,'dir')
    mkdir(strBaseDir)
end
skippedTrials = queryeevskippedtrials(strSubject,strTask,strSession);

%% Find and sort all Vicon csv files in Vicon dir
casAsciiFiles = getpatternfiles('supination_pronation(?<num>\d{2,3}).csv',strViconDir,'cas');
casAsciiFiles = sortcasfiles(casAsciiFiles,strTask);

% Initialize keyRelease variable and filename that key release times will be saved
keyReleases = nan(length(casAsciiFiles),1);
strKeyReleaseFile = fullfile(strViconDir,'key_releases_all.mat');

for i = 1:length(casAsciiFiles)
    strFile = casAsciiFiles{i};
    numTrial = trialnumfromviconfilename(strFile);
    if find(skippedTrials==numTrial)
        fprintf('\nSkipping analysis on %s',strFile)
        continue
    end
    
    % Read csv file exported from Nexus
    sBatch = viconasciiread(strFile,0);
    sKinematics = mat2struct(sBatch.trialData,sBatch.casLabels);
    if ~isfield(sKinematics,'zkeyboard')
        fprintf('\nKeyboard not found, plotting all zeros.')
        key = zeros(size(sKinematics.field));
    else
        key = sKinematics.zkeyboard;
    end
    [iKeyRelease,hAxTrial] = process_spacebar(key,'cycle',strKeyReleaseFile,strFile,i,'no');


    [H,strFigure,strPDF] = getcurrentplotset(strViconDir,'key_release_figs');
    numExistingPlots = getnumexistingsubplots(H);
    numNewPlot = numExistingPlots+1;
    hAxDest = subplot(3,2,numNewPlot);
    copyaxchildren(hAxTrial,hAxDest);
    H = gcf;

    strField = numtoword(numNewPlot);
    s.(strField).name = basename(strFile);
    guidata(H,s)
    hgsave(H,strFigure)

    if numNewPlot == 6 || i == length(casAsciiFiles)
        % Save to .pdfs and .fig formats
        printpdf(H,strPDF,'portrait')
        %hgsave(H,strFigure);

    end

    keyReleases(i) = iKeyRelease;
    casAsciiFilesSaved = casAsciiFiles;
    save(strKeyReleaseFile,'keyReleases','casAsciiFilesSaved');
    hgsave(H,strFigure)
    if numNewPlot == 6 || i == length(casAsciiFilesSaved)
        set(H,'CloseRequestFcn','guieditmovetimesclosefcn')
        hgsave(H,strFigure);
        closereq
        close all
    end
end
close all;