function guieditmovetimesclosefcn
% guieditmovetimesclosefcn.m - to be used as a close request function for a
% figure containing 6 subplots for EEV first motion detection
%
% EXAMPLE
% strFigure = 'S:\data\upper\eeg_emg_vicon\c1363plas\pre\wheel_position_velocity.fig';
% H = hgload(strFigure);
% set(H,'CloseRequestFcn','guieditmovetimesclosefcn')

% Author - Krisanne Litinas
% $Id: guieditmovetimesclosefcn.m 5402 2010-06-11 20:23:21Z klitinas $

h = gcbf;

% Find all (usually 6) cursors using regular expression matching on tags
hCursors = findobj('-regexp','tag','drag*');
casTags = get(hCursors,'tag');
[~,iSub] = sortcasfiles(casTags,'dragCursor_');
numPlots = length(hCursors);

% Use guidata to find trialnums
s = guidata(h);
sfields = fieldnames(s);
movefields = strfind(sfields,'_move');
iMoveFields = findnonemptycells(movefields);
namefields = sfields;

% Initialize things here
namefields(iMoveFields) = [];
casTitles = cell(1,6);
iTrials = nan(1,numPlots);

for i = 1:length(namefields)
    strTitle = s.(namefields{i}).name;
    casTitles{i} = strTitle;
    iNumTrial = regexp(strTitle,'\d');
    numTrial = str2double(casTitles{i}(iNumTrial));
    iTrials(i) = numTrial;
end
casTitles = casTitles(:);

% Get x position of all cursors
xx = get(hCursors,'xData');
xCursor = cellfun(@unique,xx);
xCursor = round(xCursor);
xCursorSort = xCursor(iSub);


% Write results to csv file
strDotFigFile = get(h,'filename');
strPath = fileparts(strDotFigFile);

sClassed = regexp(strDotFigFile,'(?<strType>key_release_figs)|(?<strType>wheel_position)','names');
strType = sClassed.strType;

switch lower(strType)
    case 'key_release_figs'
        strMatFile = fullfile(strPath,'key_releases_all.mat');
        load(strMatFile);
        for j = 1:numPlots
            strTitle = casTitles{j};
            strPattern = ['.*' strTitle '.*'];
            iMatch = regexp(casAsciiFilesSaved,strPattern);
            iMatch = findnonemptycells(iMatch);
            keyReleases(iMatch) = xCursorSort(j);
        end
        save(strMatFile,'casAsciiFilesSaved','keyReleases')
    case 'wheel_position'
        strCSV = fullfile(strPath,'first_motion_index.csv');
        % Read CSV file into string
        fid = fopen(strCSV);
        cOld = textscan(fid,'%s','delimiter','\n');
        c = cOld{:};
        
        % Loop through all plots and replace lines with new data
        d = cell(1,numPlots);
        lineNum = zeros(numPlots,1);
        for j = 1:numPlots;
            strField = sfields{j};
            sFig = s.(strField);
            strLineToFind = sFig.name;
            
            % Get the line number to replace
            lineNum(j) = eevgetcsvlinenum(strLineToFind,c);
            
            strTrialBoundsStart = num2str(sFig.trialBoundsStart);
            strTrialBoundsEnd = num2str(sFig.trialBoundsEnd);
            strSynchPulse = num2str(sFig.synchPulse);
            
            cursorPosUpSample = 10*xCursorSort(j);
            strCursorPosUpSample = num2str(cursorPosUpSample);
            strCursorFromStart = num2str(sFig.trialBoundsStart + cursorPosUpSample);
            str = [sFig.name ',' sFig.strMovement ',' strTrialBoundsStart ',' strTrialBoundsEnd ',' strSynchPulse ',' strCursorPosUpSample ',' strCursorFromStart];
            d{j} = str;
        end
        d = d';
        
        % Substitute the appropriate lines to be overwritten and close figure
        c(lineNum) = d;
        fclose(fid);
        
        % Completely overwrite the file, line by line
        fid = fopen(strCSV,'w');
        for i = 1:length(c)
            strLine = c{i};
            if isempty(strLine) || ~isempty(findstr(strLine,'trial'))
                strFmt = '%s,%s,%s,%s,%s,%s,%s';
                casLine = {'trial' 'move' 'start' 'end' 'synch' 'iFirstMv' 'iFM_abs'};
            else
                strFmt = '\n%s,%s,%s,%s,%s,%s,%s';
                casLine = strsplit(',',strLine);
            end
            fprintf(fid,strFmt,casLine{1},casLine{2},casLine{3},casLine{4},casLine{5},casLine{6},casLine{7});
        end
        fclose(fid);
        
        % Save figure to a new file, so we don't overwrite old JIC
        strNewFigure = eevgetmanfixfilename(strDotFigFile);
        hgsave(h,strNewFigure);
end

% Close figure window
closereq