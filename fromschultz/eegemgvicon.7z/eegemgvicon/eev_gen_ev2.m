function eev_gen_ev2(strDir,tMoveInEEG,fsEEG,casMovesAll,strMove)
% eev_gen_ev2.m - generates .ev2 script file for EEV MRCP calculation for
% specific move set [ex. pronation or supination]
% 
% INPUTS
% strDir - string, directory name to save file to
% tMoveInEEG - vector of move times
% fsEEG - sampling rate EEG signal, in seconds
% casMovesAll - cell array of strings containing movement name for each trial
% strMove - string, which movement [ex 'pro' or 'sup'] to parse out
% 
% OUTPUTS
% [implicit] ev2 file containing first motion move times in EEG record
% 
% EXAMPLE
% eev_gen_ev2(strDir,iMoveInEEG,casMovesAll,strMove);

% Author - Krisanne Litinas
% $Id: eev_gen_ev2.m 4639 2010-02-17 16:31:36Z klitinas $


% tMoveInEEG = iMoveInEEG / fsEEG;

% Find only trials of interest [in terms of movement]
iMove = getindexofonemove(casMovesAll,strMove);
moveTimes = tMoveInEEG(iMove);

% Write the static columns that are seen in ev2 files
numRows = length(moveTimes);
colOne = 1:numRows;
colTwo = ones(numRows,1);
colThree = zeros(numRows,1);
colFour = zeros(numRows,1);
colFive = zeros(numRows,1);
colSix = moveTimes;

% Make sure columns are actual columns [not rows]
colOne = colOne(:);
colSix = colSix(:);

% strFileName = [strSubject,'_',strTest,'_',strMove,'_',strSession,'.ev2'];
% strFullFile = fullfile(strDir,strFileName);
strFullFile = getscriptfilename(strDir,'.ev2',strMove);

% Write the file
fid = fopen(strFullFile,'a');
strFmt = '%d\t%d\t%d\t%d\t%d\t%0.4f\n';
for i = 1:numRows
    one = colOne(i);
    two = colTwo(i);
    three = colThree(i);
    four = colFour(i);
    five = colFive(i);
    six = colSix(i);
    fprintf(fid,strFmt,one,two,three,four,five,six);
end
fclose(fid);
