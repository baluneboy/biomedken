function strNewFigure = eevgetmanfixfilename(strDotFigFile)
% eevgetmanfixfilename.m - returns name of "manual_fix" filename to write to
% 
% INPUTS
% strDotFigFile - string, full .fig filename of the subplot figure being opened
% 
% OUTPUTS
% strNewFigure - string, full .fig filename to write manual fixes to
% 
% EXAMPLE
% strFile = 'S:\data\upper\eeg_emg_vicon\c1363plas\pre\wheel_position_velocity_10_manual_fixes_01.fig';
% strNewFile = eevgetmanfixfilename(strFile)

% Author - Krisanne Litinas
% $Id$

% If it's the original file, append '_manual_fixes_01' to filename
if isempty(strfind(strDotFigFile,'manual_fixes'))
    strNewFigure = strrep(strDotFigFile,'.fig','_manual_fixes_01.fig');

% If it's a file containing previous manual fixes, increment
% '_manual_fixes_##.fig' by one
else
    n = regexp(strDotFigFile,'\d{2}.fig','match');
    strN = n{1};
    numFix = regexp(strN,'\d{2}');
    numNewFix = numFix+1;
    strNewFix = num2str(numNewFix);
    if length(strNewFix)==1
        strNewFix = ['0' strNewFix];
    end
    strNewFigure = strrep(strDotFigFile,strN,[strNewFix '.fig']);
end