function count = countviconsynchpulses(casFiles,skippedTrials)
% countviconsynchpulses.m - returns total count of 50ms pulses in vicon
% files for a trial
% 
% INPUTS
% casFiles - csv files to check
% skippedTrials - vector of trialnums to skip
% 
% OUTPUTS
% count - total number of 50ms pulses found in all trials
% 
% EXAMPLE
% strDir = 'F:\data\upper\vicon\dalyUE\upperControl\20091123_c1363plas';
% casFiles = getpatternfiles('.csv$',strDir,'cas');
% skippedTrials = [60 63];
% numPulses = countviconsynchpulses(casFiles,skippedTrials);

% Author - Krisanne Litinas
% $Id: countviconsynchpulses.m 4627 2010-02-16 19:27:49Z klitinas $

count = zeros(length(casFiles),1);

for i = 1:length(casFiles)
    strFile = casFiles{i};
    if find(skippedTrials==i)
        count(i) = checkskippedtrialforpulse(strFile);
        continue
    end
    
    % Read csv file exported from Nexus
    s = viconasciiread(strFile,0);
    iEvt = findnonemptycells(strfind(s.casAnalogLabels,'evt'));
    evt = s.analogData(:,iEvt);
    [~,durs] = getleadingedgesdurations(evt,4);
    
    iFifty = find(durs < 55 & durs > 45);
    numPulses = length(iFifty);
    count(i) = numPulses;
end