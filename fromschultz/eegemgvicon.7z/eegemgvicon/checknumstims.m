function checknumstims(iTask,casFiles)
% checknumstims.m - compares number of laptop pulses with number of
% vicon ascii files
% 
% INPUTS
% iTask - vector, index of trials [all tasks combined] in laptop .mat file
% casFiles - cell array of strings containing vicon ascii file names
% 
% OUTPUTS
% none explicit, but errors out if number of vis stims different than
% number of vicon ascii files
% 
% EXAMPLE
% checknumstims(iSup,iPro,casFiles)

% Author - Krisanne Litinas
% $Id$

numLaptopPulses = length(iTask);
if numLaptopPulses ~= length(casFiles)
    error('daly:eegemvicon','error:unequal number of ascii files (%d) to laptop pulses (%d)',length(casFiles),numLaptopPulses)
end
