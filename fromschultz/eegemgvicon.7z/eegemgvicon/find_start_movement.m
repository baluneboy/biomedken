function ontimes = find_start_movement(m,thresh)
% find_start_movement.m
% 
% INPUTS
% m - column vector containing one component of trajectory OR
%   - 3-column matrix containing [x y z] components of marker trajectory
% thresh - threshold that diff(m) must cross to be considered significant; default is 2
% 
% OUTPUTS
% ontimes - inflection points of marker
% 
% EXAMPLE
% keytimes = find_start_movement(zkeyboard);
% keytimes = find_start_movement([xkeyboard ykeyboard zkeyboard]);
% keytimes = find_start_movement([xkeyboard ykeyboard zkeyboard],3);

% Author: Krisanne Litinas
% $Id: find_start_movement.m 4627 2010-02-16 19:27:49Z klitinas $

% Computes m if x,y,and z components are defined
if nCols(m) == 3
    mx = m(:,1);
    my = m(:,2);
    mz = m(:,3);
    m = sqrt(mx.^2 + my.^2 + mz.^2);
end
m = demean(m); % subtracts mean of signal [needed for resample]
m_resample = resample(m,1,4);
d = diff(m_resample);

if nargin == 1
    thresh = 2;
end

% find all places where diff > thresh
allJumps = find(d>thresh);

% Finds if two consecutive points are above threshold and only takes the
% first instance
duplicateJumps = [0; diff(allJumps)] == 1;
ontimes = allJumps(~duplicateJumps);
