function [evtData,fs] = getemgevt(strFile)
% getemgevt.m - returns event marker channel data and sampling rate from EMG .smr file
% 
% EXAMPLE
% strFile = 'S:\data\upper\eeg_emg_vicon\c1363plas\pre\emg\wrist.smr';
% [evtData,fsEMG] = getemgevt(strFile);

% Author - Krisanne Litinas
% $Id: getemgevt.m 4627 2010-02-16 19:27:49Z klitinas $

% Read file
fid = fopen(strFile,'r');
[evtData,hdr] = songetchannel(fid,11,'scale');
fs = hdr.sampleinterval;
fclose(fid);
