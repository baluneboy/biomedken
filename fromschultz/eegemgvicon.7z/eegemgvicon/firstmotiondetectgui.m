function varargout = firstmotiondetectgui(varargin)
%FIRSTMOTIONDETECTGUI M-file for firstmotiondetectgui.fig
%      FIRSTMOTIONDETECTGUI, by itself, creates a new FIRSTMOTIONDETECTGUI or raises the existing
%      singleton*.
%
%      H = FIRSTMOTIONDETECTGUI returns the handle to a new FIRSTMOTIONDETECTGUI or the handle to
%      the existing singleton*.
%
%      FIRSTMOTIONDETECTGUI('Property','Value',...) creates a new FIRSTMOTIONDETECTGUI using the
%      given property value pairs. Unrecognized properties are passed via
%      varargin to firstmotiondetectgui_OpeningFcn.  This calling syntax produces a
%      warning when there is an existing singleton*.
%
%      FIRSTMOTIONDETECTGUI('CALLBACK') and FIRSTMOTIONDETECTGUI('CALLBACK',hObject,...) call the
%      local function named CALLBACK in FIRSTMOTIONDETECTGUI.M with the given input
%      arguments.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help firstmotiondetectgui

% Last Modified by GUIDE v2.5 10-Mar-2011 07:04:25

% Begin initialization code - DO NOT EDIT
gui_Singleton = 0;
gui_State = struct('gui_Name',       mfilename, ...
    'gui_Singleton',  gui_Singleton, ...
    'gui_OpeningFcn', @firstmotiondetectgui_OpeningFcn, ...
    'gui_OutputFcn',  @firstmotiondetectgui_OutputFcn, ...
    'gui_LayoutFcn',  [], ...
    'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before firstmotiondetectgui is made visible.
function firstmotiondetectgui_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   unrecognized PropertyName/PropertyValue pairs from the
%            command line (see VARARGIN)

% Choose default command line output for firstmotiondetectgui
handles.output = hObject;
handles.figDetail = hObject;

% Initialize plot
set(handles.edPeakDelta,'String','');
[hAxThatWasClicked,hChildrenToCopy,handlesFromParent,strTitle] = deal(varargin{:});
handles.handlesFromParent = handlesFromParent;
handles.fs = handlesFromParent.fs;
handles = locInit(hAxThatWasClicked,hChildrenToCopy,strTitle,handles);

% Set figure props
set(hObject,'NumberTitle','off','Name','FirstMotionDetection');

% Maximize the GUI
set(hObject,'Visible','on');
maximize(hObject);

% Name the figure title bar
set(hObject,'Name',sprintf('First Motion Detection Details, Trial %02d of EEV4BCI',handlesFromParent.trial));

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes firstmotiondetectgui wait for user response (see UIRESUME)
uiwait(hObject);

% --- Outputs from this function are returned to the command line.
function varargout = firstmotiondetectgui_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% % FIXME MATLAB guide bug (handles seemed to be empty without this line)
% handles = guidata(hObject);

% Get default command line output from handles structure
varargout{1} = handles.iFirstMove;
delete(hObject);

% --- Executes on figure key press (when focus on fig and no controls selected)
function ax_KeyPressFcn(src,evnt,bln)
% src is handle of axes who's buttondownfcn is being handled by this callback
% evnt not sure what this is really
% myArg is arg passed when this callback was set
if ~bln
    disp('ButtonDownFcn callback not executed...')
    return
end
hFig = get(src,'Parent');
if strcmp(get(hFig,'SelectionType'),'alt')
    uiwait(msgbox('detected ctrl key click, but we are not handling that for now','Please close GUI via front-panel button.','modal'));
else
    disp('[not yet] USE Ctrl key while clicking axes to trigger [beyond] the "detail" GUI.')
end

% --- Executes on axes key press (when focus on fig and no controls selected)
function fig_KeyPressFcn(hObject, eventdata, handles)
% hObject    handle to fig (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% x, y, z, v, f, 9, 0
currChar = get(hObject,'CurrentCharacter');
% Control visibility
switch lower(currChar)
    case {'x','y','z','v','f','s','r'} % toggle angle lines for this axis (or first motion lines)
        locToggleAngle(currChar,handles);
%     case 'r'
%         locToggleRate(currChar,handles);
    otherwise
        % do nothing (for now)
end % switch
strTagPat = '^[xyzvr]\d{2}$';
hLinesVis = set_ylim_visible(hObject,strTagPat); %#ok<NASGU>

% --------------------------------------
function locToggleRate(currChar,handles)
newState = locToggleCheckBox(currChar,handles);
if newState
    set(handles.r99,'vis','on');
else
    set(handles.r99,'vis','off');
end

% ---------------------------------------
function locToggleAngle(currChar,handles)
newState = locToggleCheckBox(currChar,handles);
hLines = findobj(gcbf,'-regexp','tag',['^' currChar '\d{2}']);
if newState
    set(hLines,'vis','on');
else
    set(hLines,'vis','off');
end

%------------------------------------------------------
function newState = locToggleCheckBox(currChar,handles)
strChkBox = ['cb' upper(currChar)];
hcb = handles.(strChkBox);
v = get(hcb,'Value');
newState = not(v);
set(hcb,'Value',newState);

% %---------------------------------------------
% function hs = locUpdateVisStimLine(t,iVisStim)
% % Plot vis stim as dim vertical line
% hs = line(t(iVisStim)*[1 1],[-180 180]);
% set(hs,'tag',sprintf('s%02d',i),'vis','on');
% set(hs,'color',0.88*[0.5 0.5 1]);

%----------------------------------------------------
function yGlobal = updateVerticalLineYlims(hAxDetail)
hFig = get(hAxDetail,'parent');
hLines = findobj(hAxDetail,'type','line');
strTagPatVert = '^[fs]\d{2}$';
hTagVert = findobj(hFig,'-regexp','tag',strTagPatVert);
hNotVert = setxor(hLines,hTagVert);
Y = cell2mat(get(hNotVert,'ydata'));
ymini = min(Y(:));
ymaxi = max(Y(:));
yrngi = abs(ymaxi-ymini);
ymin = ymini - 0.12*yrngi;
ymax = ymaxi + 0.12*yrngi;
hFS = findobj(hAxDetail,'-regexp','tag','^[fs]\d{2}$');
yGlobal = [ymin ymax];
set(hFS,'ydata',yGlobal);

%-----------------------------------------------------------------------
function handles =  locInit(hAxClicked,hChildrenToCopy,strTitle,handles)

% FIXME disable some detail parameter changes/update (for now)
set([handles.edPeakDelta handles.pumMethod handles.rbAuto handles.rbManual handles.pbUpdate],'enable','off');

% Copy kids and set vis
handles.hCopied = copyobj(hChildrenToCopy,handles.axDetail);
set(handles.hCopied,'vis','off');

% Identify vangle from kids handles
hV = findobj(handles.axDetail,'-regexp','tag','v\d{2}');
handles.t = get(hV,'xdata');
handles.v = get(hV,'ydata');

% Get/plot abs smooth angular RATE
ud = get(hAxClicked,'userdata');
axes(handles.axDetail);
hold on
handles.r99 = plot(ud.t,ud.absSmoothAngularRate,'m');
set(handles.r99,'marker','.','tag','r99');

% Title it
casTitle = {['Rate for ' strTitle],'manually drag green line if you want to change to "better" first motion time'};
title(casTitle);
xlabel('Time(s)');

% Set checkboxes for "R" and "F" and "S" to "checked"
set(handles.cbR,'Value',1);
set(handles.cbF,'Value',1);
set(handles.cbS,'Value',1);

% Turn "F" and "S" back on
hF = findobj(handles.axDetail,'-regexp','tag','f\d{2}');
hS = findobj(handles.axDetail,'-regexp','tag','s\d{2}');
set([hF hS],'vis','on');
handles.hLineFirstMoveDetail = hF;
handles.iFirstMove = handles.handlesFromParent.iFirstMove;

yGlobal = updateVerticalLineYlims(handles.axDetail);

% Set ylim
ymin = min(ud.absSmoothAngularRate);
ymax = max(ud.absSmoothAngularRate);
set(handles.axDetail,'ylim',[ymin-0.1*abs(ymin) ymax+0.1*abs(ymax)]);

% Make first motion line "snap draggable"
udSnap = getsnapuserdata(handles.handlesFromParent.t,yGlobal);
set(hF,'YData',yGlobal);
set(hF,'UserData',udSnap);
draggable(hF,'horizontal',@snapmotionfcn);

% Set xlim from 90% of iVisStim to max(t)
xmin = 0.9*ud.t(handles.handlesFromParent.iVisStim);
set(handles.axDetail,'xlim',[xmin 1.01*max(ud.t)]);
set(handles.axDetail,'box','on');

% Update guidata
guidata(handles.figDetail, handles);

%--------------------------------
function locGetFirstMove(handles)
% Update handles structure
xd = get(handles.hLineFirstMoveDetail,'xdata');
handles.iFirstMove = round((xd(1)+(1/handles.fs))*handles.fs);
guidata(handles.figDetail, handles);

% --- Executes on button press in pbSave
function pbReject_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
uiwait(msgbox('WHAT SHOULD WE DO BESIDES TEMP LOG db TABLE?','NOTE 4 KEN...','modal'));
handles.iFirstMove = handles.handlesFromParent.iFirstMove;
guidata(handles.figDetail,handles);
uiresume(handles.figDetail);

% --- Executes on button press in pushbutton1.
function pbAccept_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
locAccept(handles);

% --- Executes when user attempts to close fig.
function fig_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to fig (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hint: delete(hObject) closes the figure
uiwait(msgbox('Only close this fig using one of the GUI buttons.','Please close GUI via front-panel button.','modal'));

%----------------------------
function locAccept(handles)
locGetFirstMove(handles);
uiresume(handles.figDetail);

%----------------------------------------------------------
function edPeakDelta_Callback(hObject, eventdata, handles)
% hObject    handle to edPeakDelta (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edPeakDelta as text
%        str2double(get(hObject,'String')) returns contents of edPeakDelta as a double
% v = str2double(get(hObject,'String'));
% if ~isnumeric(v)
%     handles.peakDelta = [];
% else
%     handles.peakDelta = v;
% end
% guidata(gcbf,handles);


% --- Executes during object creation, after setting all properties.
function edPeakDelta_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edPeakDelta (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in pumMethod.
function pumMethod_Callback(hObject, eventdata, handles)
% hObject    handle to pumMethod (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns pumMethod contents as cell array
%        contents{get(hObject,'Value')} returns selected item from pumMethod
contents = get(hObject,'String');
strMethod = contents{get(hObject,'Value')};
disp(strMethod);

% --- Executes during object creation, after setting all properties.
function pumMethod_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pumMethod (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pbUpdate.
function pbUpdate_Callback(hObject, eventdata, handles)
% hObject    handle to pbUpdate (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% FIXME peak delta value is not used (yet)
% v = str2double(get(handles.edPeakDelta,'String'));
% if ~isnumeric(v)
%     peakDelta = [];
% else
%     peakDelta = v;
% end
% contents = get(handles.pumMethod,'String');
% strMethod = contents{get(handles.pumMethod,'Value')};
% H = handles.handlesFromParent;
% indNewFirstMove = findfirstmovefromangle(handles.v,H.fs,H.iVisStim,H.timeToReact,strMethod);
uiwait(msgbox('FIXME this functionality not implemented yet, so not allowed (yet)','talk to Ken or Krisanne if you want more details','modal'));

% --- Executes when selected object is changed in uipanel4.
function uipanel4_SelectionChangeFcn(hObject, eventdata, handles)
% hObject    handle to the selected object in uipanel4 
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
switch get(hObject,'Tag')
    case 'rbAuto'
        set(handles.edPeakDelta,'string','');
        set([handles.stPeakDelta handles.edPeakDelta],'vis','off');
    case 'rbManual'
%         set(handles.edPeakDelta,'string','0.5');        
%         set([handles.stPeakDelta handles.edPeakDelta],'vis','on');
        uiwait(msgbox('FIXME this functionality not implemented yet, so not allowed (yet)','Only auto mode in peak detection (for now)','modal'));
        set(handles.rbAuto,'Value',1);
        set(handles.rbManual,'Value',0);
    otherwise
        % FIXME Code for when there is no match.
end % switch


% ------------------------------------------------------
function menuOther_Callback(hObject, eventdata, handles)
% hObject    handle to menuOther (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% -------------------------------------------------------------------------
function miRestoreOriginalFirstMotion_Callback(hObject, eventdata, handles)
% hObject    handle to miRestoreOriginalFirstMotion (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
H = handles.handlesFromParent;
ifm = H.originalFirstMotion;
xd = get(handles.hLineFirstMoveDetail,'xdata');
tCurrent = xd(1);
iCurrent = find(H.t==tCurrent);
locUpdateFirstMove(iCurrent,ifm,handles);

%-----------------------------------------------------------------
% FIXME this should get refactored with "parent" gui code
function locUpdateFirstMove(iFirstMoveIn,iFirstMoveOut,handles)
if iFirstMoveIn ~= iFirstMoveOut
    handles.iFirstMove = iFirstMoveOut;
    set(handles.hLineFirstMoveDetail,'xdata',handles.t(iFirstMoveOut)*[1 1]);
    guidata(handles.figDetail,handles);
end
