function iFifty = eegevtparse(evt)
% eegevtparse.m - finds 50ms pulses from "cherry" event marker signal
% 
% INPUTS
% evt - vector, cherry event marker channel data
% 
% OUTPUTS
% iFifty - indices of 50ms leading edges
% 
% EXAMPLE
% strFileEEG = 'S:\data\upper\eeg_emg_vicon\c1363plas\pre\eeg\wrist.cnt';
% evt = geteegevt(strFileEEG);
% iFifty = eegevtparse(evt);

% Author - Krisanne Litinas
% $Id: eegevtparse.m 4627 2010-02-16 19:27:49Z klitinas $

% Demean evt to account for any offset
evtDemean = demean(evt);

% Normalize the demeaned signal
evtNorm = normalize(evtDemean);

% Try a snap2grid?
% y = snap2grid(evtNorm,0,0.1,1);

% Apply histogram to signal and find top three bins
% edges = 0:0.05:1;
edges = 0:0.05:1;
[n,iBin] = histc(evtNorm,edges);
% [n,iBin] = histc(y,edges);

% Set any indices not in three top bins to mean of signal [to get rid of spikes
[~,i] = sort(n,'descend');
iGood = i(1:3);
% iGood = i(1:5);
iToss = ~ismember(iBin,iGood);
evtFilt = evtNorm;
evtFilt(iToss) = mean(evtFilt);
% evtFiltNorm = normalize(evtFilt);
% y = snap2grid(evtFiltNorm,0,0.1,1);
% evtFiltDemean = demean(y);
% evtFiltRect = abs(evtFiltDemean);
% evtFiltRectNorm = normalize(evtFiltRect);
% Demean, rectify, and normalize the filtered signal
evtFiltDemean = demean(evtFilt);
evtFiltRect = abs(evtFiltDemean);
evtFiltRectNorm = normalize(evtFiltRect);

% Apply threshhold to normalized signal and grab indices of leading edges [pulses]
thresh = 0.4;
indEdges = getleadingedgesdurations(evtFiltRectNorm,thresh);

% Use diff to find intervals between pulses
diffInds = diff(indEdges);

% Find 50ms pulses based on interval between spikes
dFiftyPulse = diffInds > 45 & diffInds < 55;
iFifty = indEdges(dFiftyPulse);