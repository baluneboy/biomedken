function wrist_hand_kinematics(strInputPath, casTasks)
% wrist_hand_kinematics - Main (wrapper) routine that does the following:
%
% 1.  Find vicon .txt files for each task
% 2.  Call viconread to import Vicon-generated marker and event data.
%
%
%

for k = 1:length(casTasks)
    strLookFor = sprintf('%s%s%s%s', strInputPath, casTasks{k},'_batch_','*.csv');
    structTmp = dir(strLookFor);
    sTaskFiles(k).task = casTasks{k};
    sTaskFiles(k).filenames = {structTmp.name};
end



% importfile
% % % % importfile(sTaskFiles)

% import eventmarker
m = dlmread(strEvtFile, '\t', 1,0);
samplenum = m(:,1);
evt = m(:,2);

% Start, duration based on event marker analog signal
% Modify this with implementation of H3K
evtPulseInds = find(evt > 40);
[st, du] = contig(evt, evtPulseInds);
st_du = [st du];
onMarkertmp = find(st_du(:,2) < 7);
onMarkerInd = st_du(onMarkertmp,1);
offMarkertmp = find(st_du(:,2) > 7);
offMarkerInd = st_du(offMarkertmp,1);

% Need to account for late 'on' event marker pulse
trueStartInd = onMarkerInd - 300;
StartEnd = [trueStartInd offMarkerInd];


for i = 1:length(StartEnd)
    % trialInd = samplenum(StartEnd(i,1): StartEnd(i,2));
    runData = data(StartEnd(i,1):StartEnd(i,2),:);
    % assign_varnames(runData, colheaders);
    casNew = regexprep(colheaders,':','_');
    for j = 1:length(casNew)
        str = lower(casNew{j});
        strCmd = [str '=runData(:,' num2str(j) ');'];
        foo = evalc(strCmd);
    end





end


