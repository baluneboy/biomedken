function eev_gen_s2s(strDir,tMoveInEMG,casMovesAll,emgOffset,strMove)
% eev_gen_s2s.m - generates .s2s script file for EEV MRCP calculation for
% specific move set [ex. pronation or supination]
% 
% INPUTS
% strDir - string, directory name to save file to
% tMoveInEMG - vector of move time indices
% casMovesAll - cell array of strings containing movement name for each trial
% emgOffset - time offset of EMG stream relative to EEG [in seconds] 
% strMove - string, which movement [ex 'pro' or 'sup'] to parse out
% 
% OUTPUTS
% [implicit] s2s file containing first motion move times in EMG record
% 
% EXAMPLE
% eev_gen_s2s(strDir,tMoveInEEG,casMovesAll,emgOffset,strMove);

% Author - Krisanne Litinas
% $Id$


% Find only trials of interest [in terms of movement]
iMove = getindexofonemove(casMovesAll,strMove);
moveTimes = tMoveInEMG(iMove);

strFileScript = getscriptfilename(strDir,'s2s',strMove);

fid=fopen(strFileScript,'w');
strComment = sprintf('''deltaEEGEMG = %.4f seconds [EMG start time relative to EEG start (EMGstart minus EEGstart)]\n\n',emgOffset);
strHeader=[strComment 'var mch%%;\nmch%% := memchan(4);\nChanTitle$(mch%%,"Events-Trigger");\nchanshow(mch%%);\ndrawMode(mch%%, 1,1);\n\n'];
fprintf(fid,strHeader);
numMoves = length(moveTimes);
for i=1:numMoves
    fprintf(fid,'memsetitem(mch%%, 0, %.4f); ''move #%02d\n',moveTimes(i),i);
end
fclose(fid);
fprintf('\nWrote %s (%d written)\n',strFileScript,numMoves)
