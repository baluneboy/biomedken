function numTrial = trialnumfromviconfilename(strFile)
% trialnumfromviconfilename.m - returns trial number given name of Vicon filename
% 
% INPUTS
% strFile - 1 string, name of Vicon file, should end in '<number>.csv'
% 
% OUTPUTS
% numTrial - 1 double, the trial number
% 
% EXAMPLE
% strFile = 'S:\data\upper\vicon\dalyUE\upperControl\c1320plas\20100315_c1320plas\supination_pronation002.csv';
% numTrial = trialnumfromviconfilename(strFile)

% Author - Krisanne Litinas
% $Id$

% Create pattern and do regular expression to get string containing trial num
strPattern = '(?<strTrialNum>\d{1,3})(?<ext>.csv)';
sMatch = regexp(strFile,strPattern,'names');
strTrialNum = sMatch.strTrialNum;

% Convert to double
numTrial = str2double(strTrialNum);