function iMove = getindexofonemove(casMovesAll,strMove)
% getindexofonemove.m
% 
% INPUTS
% casMovesAll - nx1 cell array of strings containing movement names, n being number of trials
% strMove - string, movement of interest
% 
% OUTPUTS
% iMove - vector containing indices of casMovesAll where strMove is found
% 
% EXAMPLE
% cas = {'one';'two';'two';'one';'one'};
% iTwo = getindexofonemove(cas,'two')

% Author - Krisanne Litinas
% $Id: getindexofonemove.m 4627 2010-02-16 19:27:49Z klitinas $

% Find only trials of interest [in terms of movement]
c = strfind(casMovesAll,strMove);
iMove = findnonemptycells(c);