function strFile = geteevfiles(strDir,strTask)
% geteevfiles.m - finds EEG (.cnt) or EMG (.smr) file given a directory/task
% 
% EXAMPLE
% strEEGDir = 'S:\data\upper\eeg_emg_vicon\c1363plas\pre\emg';
% strTask = 'wrist';
% strFileEMG = geteevfiles(strEEGDir,strTask);

% Author - Krisanne Litinas
% $Id: geteevfiles.m 4627 2010-02-16 19:27:49Z klitinas $

% If it's plasticity, supination_pronation task = wrist task
if strcmp(strTask,'supination_pronation')
    strTask = 'wrist';
end
strPattern = [strTask '.cnt|' strTask '.smr'];
casFiles = getpatternfiles(strPattern,strDir,'cas');

% If there's more than one file, error out until workflow is improved
if length(casFiles)>1
    error('error:daly:eegemgvicon','error: no workflow yet for more than one file in %s',strDir)
else
    strFile = casFiles{1};
end