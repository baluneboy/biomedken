function numPulses = checkskippedtrialforpulse(strFile)
% checkskippedtrialforpulse.m - for skipped trials, returns any events that were hit and present in EEG and EMG datasets
%
% INPUTS
% skippedTrials - vector containing trial numbers skipped
%
% OUTPUTS
% iSkips - index of 50ms pulses to skip
%
% EXAMPLE
% strFile = 'F:\data\upper\vicon\dalyUE\upperControl\20091123_c1363plas\supination_pronation063.csv';
% numPulses = checkskippedtrialforpulse(strFile);

% Author - Krisanne Litinas
% $Id: checkskippedtrialforpulse.m 4627 2010-02-16 19:27:49Z klitinas $

% Try reading the vicon file [is it blank?]
try
    s = viconasciiread(strFile,'supress');
end

% If it's not a dummy file, s exists.  Check for number of pulses
if exist('s','var')
    iEvt = findnonemptycells(strfind(s.casAnalogLabels,'evt'));
    evt = s.analogData(:,iEvt);
    [~,durs] = getleadingedgesdurations(evt,4);
    iFifty = find(durs < 55 & durs > 45);
    numPulses = length(iFifty);
    fprintf('\nFound %d 50ms pulses in skipped trial file %s\n',numPulses,strFile)
else
    % Dummy file, no pulses present
    numPulses = 0;
end

