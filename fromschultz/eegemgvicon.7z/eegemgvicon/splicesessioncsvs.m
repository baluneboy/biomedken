function splicesessioncsvs(strDir)
% EXAMPLE
% strDirVicon = 'Z:\upperStroke\s1366plas\20090826_s1366plas';
% splicesessioncsvs(strDirVicon)

strPattern = 'batch(?<num>\d{1,3}).csv';
casFilesBatch = getpatternfiles(strPattern,strDir,'cas');

for i = 1:length(casFilesBatch)
    strFile = casFilesBatch{i};
    fprintf('\n%s%s','Splicing file: ',strFile);
    eevcsvsplice(strFile)
end