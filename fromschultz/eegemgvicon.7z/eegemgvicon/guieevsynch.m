function emgOffset = guieevsynch(eeg,emg,iEEG,iEMG,fsEEG,fsEMG)
% guieevsynch.m
% 
% INPUTS
% eeg - event marker channel data from stroke-eeg
% emg - event marker channel data from stroke-emg
% iEEG - indices of pulses in EEG signal
% iEMG - indices of pulses in EMG signal
% 
% OUTPUTS
% eegOffset - eeg event mark offset relative to emg

% Author - Krisanne Litinas
% $Id: guieevsynch.m 5402 2010-06-11 20:23:21Z klitinas $


if length(iEEG) < 4
    iEEG = [2000 2050 4000 4100];
end

% Generate t vectors for EMG
tEMG = gent(emg,fsEMG);

% Get offset EEG relative to EMG [that was calculated automatically]
eegOffset = iEEG(1) - iEMG(1);
iShiftedEEG = iEEG - eegOffset;

% Shift EEG signal to line up with EMG to plot it
eegShift = eeg;
%eegShift(1:eegOffset-1) = [];
tEEG = gent(eegShift,fsEEG);

% Grab snip of EEG and EMG sets, 4 pulses-worth
emgSnip = emg(1:iEMG(4));
eegSnip = eegShift(1:iEMG(4));

H = figure;

% Set x range to plot
xRange = [iEMG(1)-1000 iEMG(4)+1000];

% EMG plot
hSubEMG = subplot(211);
haxEMG = gca;
hEMG = plot(emgSnip);
hold on
yPulseEMG = repmat(0,4,1);
hPulseEMG = plot(iEMG(1:4),yPulseEMG,'ro');
set(hPulseEMG,'markersize',10);
set(hPulseEMG,'linewidth',2.5);
set(haxEMG,'xlim',xRange);
% set(haxEMG,'ylabel','EMG event');

% EEG plot
hSubEEG = subplot(212);
haxEEG = gca;
hEEG = plot(eegSnip);   
hold on
yPulseEEG = repmat(mean(eegSnip),4,1);
% hPulseEEG = plot(iShiftedEEG(1:4),yPulseEEG,'r+');
hPulseEEG = plot(iEMG(1:4),yPulseEEG,'r+');

set(hPulseEEG,'linewidth',2.5);
set(hPulseEEG,'markersize',10)
set(haxEEG,'xlim',xRange);
% set(haxEEG,'ylabel','EEG event');
% set(haxEEG,'xlabel','Sample Num')


% Set EEG and EMG to draggable for manual correction
draggable(hPulseEEG,'horizontal',[0 20e8]);
draggable(hPulseEMG,'horizontal',[0 20e8]);

% Pause to allow user to drag cursor(s)
pause

% Re-calculate offset based on old offset and new corrected
iPulseEEG = get(hPulseEEG,'xData');
iFirstPulseEEG = round(iPulseEEG(1));

iPulseEMG = get(hPulseEMG,'xData');
iFirstPulseEMG = round(iPulseEMG(1));
% emgOffset = -(eegOffset+iFirstPulseEEG - iShiftedEEG(1));
emgOffset = iFirstPulseEMG - iFirstPulseEEG;
