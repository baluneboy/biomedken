function iMove = getviconfirstmotion(y,strMovement,strFile)
% getviconfirstmotion.m - finds index of first motion of a given trajectory
% 
% EXAMPLE
% v = [1 1 1 1.2 1.3 1.3 1.5 1.5];
% iMove = getviconfirstmotion(v);

% Find filtered angular velocity given filter parameters
order = 5; 
fc = 2;
fs = 100;

% Flip signal if trial is pronation
if strcmp(strMovement,'pro')
    y = -y;
end

[dydt,t] = filtdydt(y,order,fc,fs,'low');

% Set threshhold for finding first motion
lowBound = -0.75;
hiBound = 0.5;

iEvent =  doublethreshold(dydt,lowBound,hiBound);
if iEvent(1) == 1
    iEvent(1) = [];
end

% Check if one event found, if not error out
if length(iEvent) == 1
    iMove = iEvent;
else
    error('daly:eegemgvicon','error in %s, %d moves found, should be 1',strFile,length(iEvent));
end