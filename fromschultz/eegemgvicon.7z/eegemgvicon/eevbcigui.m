function iFirstMove = eevbcigui(trial,s,iEvt,iVisStim,fs,casFocus,casIgnore,timeToReact)

% EEVBCIGUI plots xyz components of joint angles, user verifies/corrects time (index) of first motion
% 
% INPUTS
% trial - scalar value for trial number
% sTraj - structure of vicon outputs (see INPUT DETAILS @ bottom)
% iEvt - scalar index of (50ms) event marker
% iVisStim - scalar index vis stim was cued
% fs - scalar sample rate (sa/sec) for angle data; nominally, 100 sa/sec
% casFocus - cas of labels that are subset of angles, considered "likely movers" in 1st motion detection
% casIgnore - cas of labels that are subset of angles to definitely ignore for 1st motion detection
% timeToReact - scalar human reaction time (for default, use gracious 150e-3s per email thread Ken has)
% 
% OUTPUTS
% iFirstMove - scalar index of first motion as determined by user
% 
% OBSOLETE EXAMPLE
% strFile = 'S:\data\upper\vicon\dalyUE\upperStroke\s1818bcis\20100504_s1818bcis\thumb_extension_forearm_neutral04.csv';
% s = viconasciiread(strFile);
% sTraj = mat2struct(s.trialData,s.casLabels);
% iEvt = 300;
% iVisStim = 150;
% iFirstMove = eevbcigui(sTraj,iEvt,iVisStim)
%
% EXAMPLE
% clear variables;
% load('g:\dropbox\ken\eevbcigui.mat');
% iFirstMove = eevbcigui(trial,sTraj,iEvt,iVisStim,fs,casFocus,casIgnore,timeToReact)

%% Grab "angle" fields of struct, i.e. dismiss xyz marker trajectories
casFields = fieldnames(s);
iAngle = findnonemptycells(strfind(casFields,'angle'));
casAngles = casFields(iAngle);
casJoints = cellfun(@(x) (x(2:end)),casAngles,'uni',false);
casJoints = unique(casJoints);

%% Call GUI for first motion (note: Krisanne's original loop moved into gui code)
iFirstMove = eevbciguifm(trial,s,iEvt,iVisStim,fs,casFocus,casIgnore,casAngles,casJoints,timeToReact);

%% INPUT DETAILS
% input structure from vicon (s or sTraj) has these fields:
% field
% xhandMedial
% yhandMedial
% zhandMedial
% xhandMid
% yhandMid
% zhandMid
% xhandLateral
% yhandLateral
% zhandLateral
% xthumbProx
% ythumbProx
% zthumbProx
% xthumbMid
% ythumbMid
% zthumbMid
% xthumbDist
% ythumbDist
% zthumbDist
% xdigit_2_hand
% ydigit_2_hand
% zdigit_2_hand
% xdigit_2_prox
% ydigit_2_prox
% zdigit_2_prox
% xdigit_2_mid
% ydigit_2_mid
% zdigit_2_mid
% xdigit_2_dist
% ydigit_2_dist
% zdigit_2_dist
% xdigit_3_hand
% ydigit_3_hand
% zdigit_3_hand
% xdigit_3_prox
% ydigit_3_prox
% zdigit_3_prox
% xdigit_3_mid
% ydigit_3_mid
% zdigit_3_mid
% xdigit_3_dist
% ydigit_3_dist
% zdigit_3_dist
% xdigit_4_hand
% ydigit_4_hand
% zdigit_4_hand
% xdigit_4_prox
% ydigit_4_prox
% zdigit_4_prox
% xdigit_4_mid
% ydigit_4_mid
% zdigit_4_mid
% xdigit_4_dist
% ydigit_4_dist
% zdigit_4_dist
% xdigit_5_hand
% ydigit_5_hand
% zdigit_5_hand
% xdigit_5_prox
% ydigit_5_prox
% zdigit_5_prox
% xdigit_5_mid
% ydigit_5_mid
% zdigit_5_mid
% xdigit_5_dist
% ydigit_5_dist
% zdigit_5_dist
% xwristMedial
% ywristMedial
% zwristMedial
% xwristLateral
% ywristLateral
% zwristLateral
% xforearmMedial
% yforearmMedial
% zforearmMedial
% xforearmLateral
% yforearmLateral
% zforearmLateral
% xforearmMid
% yforearmMid
% zforearmMid
% xelbow
% yelbow
% zelbow
% xshoulder
% yshoulder
% zshoulder
% xkeyboard
% ykeyboard
% zkeyboard
% xangle_digit_2_dist
% yangle_digit_2_dist
% zangle_digit_2_dist
% xangle_digit_2_hand
% yangle_digit_2_hand
% zangle_digit_2_hand
% xangle_digit_2_prox
% yangle_digit_2_prox
% zangle_digit_2_prox
% xangle_digit_3_dist
% yangle_digit_3_dist
% zangle_digit_3_dist
% xangle_digit_3_hand
% yangle_digit_3_hand
% zangle_digit_3_hand
% xangle_digit_3_prox
% yangle_digit_3_prox
% zangle_digit_3_prox
% xangle_digit_4_dist
% yangle_digit_4_dist
% zangle_digit_4_dist
% xangle_digit_4_hand
% yangle_digit_4_hand
% zangle_digit_4_hand
% xangle_digit_4_prox
% yangle_digit_4_prox
% zangle_digit_4_prox
% xangle_digit_5_dist
% yangle_digit_5_dist
% zangle_digit_5_dist
% xangle_digit_5_hand
% yangle_digit_5_hand
% zangle_digit_5_hand
% xangle_digit_5_prox
% yangle_digit_5_prox
% zangle_digit_5_prox
% xangle_elbow
% yangle_elbow
% zangle_elbow
% xangle_thumb_dist
% yangle_thumb_dist
% zangle_thumb_dist
% xangle_thumb_hand
% yangle_thumb_hand
% zangle_thumb_hand
% xaxx_forearm
% yaxx_forearm
% zaxx_forearm
% xaxx_hand
% yaxx_hand
% zaxx_hand
% xaxy_forearm
% yaxy_forearm
% zaxy_forearm
% xaxy_hand
% yaxy_hand
% zaxy_hand
% xaxz_forearm
% yaxz_forearm
% zaxz_forearm
% xaxz_hand
% yaxz_hand
% zaxz_hand
% xo_forearm
% yo_forearm
% zo_forearm
% xo_hand
% yo_hand
% zo_hand
% xAngleNorm
% yAngleNorm
% zAngleNorm
% xangleHandGround
% yangleHandGround
% zangleHandGround
% xangleForearmGround
% yangleForearmGround
% zangleForearmGround
% xangleHandForearm
% yangleHandForearm
% zangleHandForearm

%% Work to be done:
%% DONE: Somehow, all 20 cursors need to slide simultaneously (ex user slides
%  cursor 5 samples left on wrist angle plot, cursor should slide 5 samples left in all plots)
%% DONE: Have routine to automatically detect first move, plot hCursor
%  there as initial value and have user drag it from there
%% DONE: Have another vertical line showing where visual stim occurred.
%% DONE: Put titles on subplots (per joint)
%% DONE: Exit option(s) do proper updates (like handles.iFirstMove)
%% DONE: "other" menu item to snap back to original first move
%% NEED: properly propagate subject/session/trial/[other?] pertinent info to titles (csv, fig filenames)
%% NEED: test/verify with good and troublesome data sets
%% NEED: thoughts from KL on SaveFig button (vs. SaveDetails or something else)
