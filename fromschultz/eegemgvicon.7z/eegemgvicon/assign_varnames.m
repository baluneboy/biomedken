function assign_varnames(data, colheaders)
casNew = regexprep(colheaders,':','_');
for i = 1:length(casNew)
   str = casNew{i};
   strCmd = [str '=data(:,' num2str(i) ');'];
   foo = evalc(strCmd);
end

