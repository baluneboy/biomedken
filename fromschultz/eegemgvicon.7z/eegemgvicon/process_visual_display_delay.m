function [taskOneDelay,iTaskOne,taskTwoDelay,iTaskTwo] = process_visual_display_delay(strFile,iSkip)
% process_visual_display_delay.m - processes mat file containing laptop display delay
% 
% INPUTS
% strFile - mat file
% iSkip - vector of keyboard presses to ignore
% 
% OUTPUTS
% taskOneDelay - nx1 vector [n = numTrials] of time delay [in msec] between key release and display event for taskOne (supination for plas task) trials
% taskTwoDelay - nx1 vector [n = numTrials] of time delay [in msec] between key release and display event for taskTwo (pronation for plas task) trials
% iTaskOne - nx1 index of taskOne trials
% iTaskTwo - nx1 index of taskTwo trials
% 
% NOTES
% Assume following sequence [plasticity]
% 1. taskOne
% 2. Relax
% 3. taskTwo
% 4. Relax
% 
% EXAMPLE
% strMatFile = 'S:\data\upper\eeg_emg_vicon\s1361plas\s1361plas_wristTask_time_delay.mat';
% [supDelay,iSup,proDelay,iPro] = process_visual_display_delay(strMatFile);

% Author - Krisanne Litinas
% $Id: process_visual_display_delay.m 5402 2010-06-11 20:23:21Z klitinas $


load(strFile,'lagTime')

% Remove lines to be skipped
if nargin == 1
    iSkip = [];
end
lagTime(iSkip,:) = [];

trigger = lagTime(:,2); 
delay = lagTime(:,4);

oneCode = 1;
twoCode = 3;

[taskOneDelay,iTaskOne] = loc_get_delay(trigger, oneCode, delay);
[taskTwoDelay,iTaskTwo] = loc_get_delay(trigger, twoCode, delay);

% Kludge for if it's a BCI task, not plasticity
if nargout==2
    iTaskOne = [iTaskOne; iTaskTwo];
    iTaskOne = sort(iTaskOne);
    
    taskOneDelay = [taskOneDelay; taskTwoDelay];
    taskOneDelay = sort(taskOneDelay);
end


% ------------------------------------------------------------------------
function [stateDelay, iState] = loc_get_delay(trigger, stateTrigger, delay)
i = trigger == stateTrigger;
stateDelay = delay(i);
iState = find(i);