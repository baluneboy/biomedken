function c = eevloadfirstmoves(strFile)
% eevloadfirstmoves.m
% 
% INPUTS
% strFile - csv file containing EEV first move info
% 
% OUTPUTS
% c - numLines x 1 cell array, each row [after header] is one trial's 
%   - strTrial
%   - strMove
%   - iViconStart
%   - iViconEnd
%   - iSynchPulse
%   - iFirstMove
%   - iFirstMoveAbsolute
% 
% EXAMPLE
% strFile = 'F:\data\upper\eeg_emg_vicon\c1363plas\pre\first_motion_index.csv';
% c = eevloadfirstmoves(strFile);

% Author - Krisanne Litinas
% $Id: eevloadfirstmoves.m 4627 2010-02-16 19:27:49Z klitinas $


% Read the file
fid = fopen(strFile);
c = textscan(fid,'%s','delimiter','\n');

% Unnest this cell
c = c{:};

% Close the file
fclose(fid);