function eevsavesubplots(H,strPDF,strFigure)
% eevsavesubplots.m - formats and saves subplots to eev directory
%
% INPUTS
% H - handle to figure
% strPDF - filename of pdf to save to
% strFigure - filename of .fig to save to
%
% OUTPUTS
% [implicit] - saved .fig and .pdf of first motion plots
% 
% EXAMPLE
% H = figure;
% plot(1:11); hold on; plot(2:12); % note callback for button won't work
% strPDF = 'c:\temp\trash.pdf';
% strFigure = 'c:\temp\trash.fig';
% eevsavesubplots(H,strPDF,strFigure)

% Author - Krisanne Litinas
% $Id$

% Format legend
hLeg = legend('Wheel Angular Velocity','Wheel Angle');
set(hLeg,'position',[0.7352 0.0215 0.1726 0.0520]);

% Add button that saves and closes the figure
hButton = uicontrol('Style','pushbutton','string','Save and Close','Position',[20 16 100 70],'Callback','guieditmovetimesclosefcn');

% Sets close function to guieditmovetimesclosefcn.m
set(H,'CloseRequestFcn','guieditmovetimesclosefcn')

% Save to .pdfs and .fig formats
printpdf(H,strPDF,'portrait')
hgsave(H,strFigure);
closereq