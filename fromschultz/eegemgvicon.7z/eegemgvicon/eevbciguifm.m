function varargout = eevbciguifm(varargin)
%EEVBCIGUIFM M-file for eevbciguifm.fig
%      EEVBCIGUIFM, by itself, creates a new EEVBCIGUIFM or raises the existing
%      singleton*.
%
%      H = EEVBCIGUIFM returns the handle to a new EEVBCIGUIFM or the handle to
%      the existing singleton*.
%
%      EEVBCIGUIFM('Property','Value',...) creates a new EEVBCIGUIFM using the
%      given property value pairs. Unrecognized properties are passed via
%      varargin to eevbciguifm_OpeningFcn.  This calling syntax produces a
%      warning when there is an existing singleton*.
%
%      EEVBCIGUIFM('CALLBACK') and EEVBCIGUIFM('CALLBACK',hObject,...) call the
%      local function named CALLBACK in EEVBCIGUIFM.M with the given input
%      arguments.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help eevbciguifm

% Last Modified by GUIDE v2.5 10-Mar-2011 06:50:29

% Begin initialization code - DO NOT EDIT
gui_Singleton = 0;
gui_State = struct('gui_Name',       mfilename, ...
    'gui_Singleton',  gui_Singleton, ...
    'gui_OpeningFcn', @eevbciguifm_OpeningFcn, ...
    'gui_OutputFcn',  @eevbciguifm_OutputFcn, ...
    'gui_LayoutFcn',  [], ...
    'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before eevbciguifm is made visible.
function eevbciguifm_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   unrecognized PropertyName/PropertyValue pairs from the
%            command line (see VARARGIN)

% Choose default command line output for eevbciguifm
handles.output = hObject;
handles.iFirstMove = NaN;

% Initialize plot
[trial,s,iEvt,iVisStim,fs,casFocus,casIgnore,casAngles,casJoints,timeToReact] = deal(varargin{:});
[handles,t] = locInitPlot(s,iEvt,iVisStim,fs,casFocus,casIgnore,casAngles,casJoints,timeToReact,handles);
handles.iVisStim = iVisStim;
handles.timeToReact = timeToReact;
handles.t = t;
handles.subject = s.subject;
handles.task = s.task;
handles.session = s.session;
handles.detailed = 0;

% Set figure props
set(hObject,'NumberTitle','off','Name','EEV_BCI_FirstMotion');

% Maximize the GUI
set(hObject,'Visible','on');
maximize(hObject);

% Name the figure title bar
set(hObject,'Name',sprintf('Trial %02d of EEV4BCI',trial));
handles.trial = trial;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes eevbciguifm wait for user response (see UIRESUME)
uiwait(hObject);

% --- Outputs from this function are returned to the command line.
function varargout = eevbciguifm_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.iFirstMove;
delete(hObject);

% Write to db eevbci.logfirstmotion
casFields = {'subject','task','session','trial','detailed','original_index_firstmotion','unofficial_index_firstmotion'};
values = {handles.subject,handles.task,handles.session,handles.trial,handles.detailed,handles.originalFirstMotion,handles.iFirstMove};
insertrecordlogfirstmotion('eevbci','logfirstmotion',casFields,values);

% --- Executes on figure key press (when focus on fig and no controls selected)
function ax_KeyPressFcn(src,evnt,bln)
% src is handle of axes who's buttondownfcn is being handled by this callback
% evnt not sure what this is really
% myArg is arg passed when this callback was set
if ~bln
    disp('ButtonDownFcn callback not exectued because this axes is not part of the "focus" group')
    return
end
hFig = get(src,'Parent');
if strcmp(get(hFig,'SelectionType'),'alt')
    handles = guidata(hFig);
    % FIXME verify handles.iFirstMove is getting updated!
    iFirstMoveIn = handles.iFirstMove;
    iFirstMoveOut = locGuiDetail(src);
    locUpdateFirstMove(iFirstMoveIn,iFirstMoveOut,handles);
    locSetGuiData(hFig,'detailed',1);    
else
    disp('USE Ctrl key while clicking axes to trigger the "detail" GUI.')
end

%------------------------------------------
function locSetGuiData(hFig,strField,value)
h = guidata(hFig);
h.(strField) = value;
guidata(hFig,h);

%-------------------------------
function ifm = locGuiDetail(hAx)
hChildrenToCopy = get(hAx,'children');
hParent = get(hAx,'parent');
handlesFromParent = guidata(hParent);
set(hParent,'vis','off');
ht = get(hAx,'title');
strTitle = get(ht,'string');
ifm = firstmotiondetectgui(hAx,hChildrenToCopy,handlesFromParent,strTitle);
set(hParent,'vis','on');

%--------------------------------------------------------------
function locUpdateFirstMove(iFirstMoveIn,iFirstMoveOut,handles)
if iFirstMoveIn ~= iFirstMoveOut
    handles.iFirstMove = iFirstMoveOut;
    set(handles.hLinesFirstMove,'xdata',handles.t(iFirstMoveOut)*[1 1]);
    guidata(handles.fig,handles);
end

% --- Executes on axes key press (when focus on fig and no controls selected)
function fig_KeyPressFcn(hObject, eventdata, handles)
% hObject    handle to fig (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% x, y, z, v, f, 9, 0
currChar = get(hObject,'CurrentCharacter');
% Control visibility
switch lower(currChar)
    case {'x','y','z','v','f','s'} % toggle angle lines for this axis (or first motion lines)
        locToggleAngle(currChar,handles);
    otherwise
        return
end % switch
strTagPat = '^[xyzvr]\d{2}$';
hLinesVis = set_ylim_visible(hObject,strTagPat); %#ok<NASGU>

% ---------------------------------------
function locToggleAngle(currChar,handles)
newState = locToggleCheckBox(currChar,handles);
hLines = findobj(gcbf,'-regexp','tag',['^' currChar '\d{2}']);
if newState
    set(hLines,'vis','on');
else
    set(hLines,'vis','off');
end

%------------------------------------------------------
function newState = locToggleCheckBox(currChar,handles)
strChkBox = ['cb' upper(currChar)];
hcb = handles.(strChkBox);
v = get(hcb,'Value');
newState = not(v);
set(hcb,'Value',newState);

%------------------------------------------
function hs = locAddVisStimLine(t,iVisStim)
% Plot vis stim as dim vertical line
hs = line(t(iVisStim)*[1 1],[-180 180]);
set(hs,'tag',sprintf('s%02d',i),'vis','on');
set(hs,'color',0.88*[0.5 0.5 1]);

%----------------------------------------------------------------------------------------------------------------
function [handles,t] = locInitPlot(s,iEvt,iVisStim,fs,casFocus,casIgnore,casAngles,casJoints,timeToReact,handles)
% FIXME set timeToReact per email discussion between MD and JZ, use 150ms
% timeToReact = 150e-3;
casOther = setxor(casJoints,union(casFocus,casIgnore));
% Loop through each of the joints (should be 18)
ymax = nan*ones(18,1);
numFocus = length(casFocus);
indFirstMove = NaN;
hAxFocus = nan*ones(numFocus,1);
countFocus = 0;
maxAmp = 0;
yminFM = inf;
ymaxFM = -inf;
for i = 1:length(casJoints)

    % Joint label
    strJoint = casJoints{i};
    strJointCamelCase = camelcase(strJoint);

    % Get all important tag info
    strAxTag = sprintf('ax%02d',i);
    axes(handles.(strAxTag));
    hold on;

    % Get appropriate x,y,z angle cols for this joint
    iJoint = findnonemptycells(strfind(casAngles,strJoint));
    casFieldsJoint = casAngles(iJoint);
    ix = findnonemptycells(strfind(casFieldsJoint,'xangle'));
    iy = findnonemptycells(strfind(casFieldsJoint,'yangle'));
    iz = findnonemptycells(strfind(casFieldsJoint,'zangle'));
    strFieldX = casFieldsJoint{ix};
    strFieldY = casFieldsJoint{iy};
    strFieldZ = casFieldsJoint{iz};

    xangle = s.(strFieldX);
    yangle = s.(strFieldY);
    zangle = s.(strFieldZ);

    if i==1
        t = gent(xangle,fs); % FIXME error check to verify xangle length same for y,z,v
    end

    % Detrend angles for slow drift removal
    xangle = detrend(xangle);
    yangle = detrend(yangle);
    zangle = detrend(zangle);

    % Calculate "vector sum" of angles
    vangle = anglevecsum(xangle,yangle,zangle);

    % Get ylim info
    ymax(i) = max(vangle);

    % Shade the ax for "focus", "ignore", otherwise
    if any(ismember(casIgnore,strJoint))
        set(handles.(strAxTag),'color',0.77*[1 1 1]);
        set(handles.(strAxTag),'buttondownfcn',{@ax_KeyPressFcn,false})
    elseif any(ismember(casOther,strJoint))
        set(handles.(strAxTag),'color',[1 1 0.75]);
        set(handles.(strAxTag),'buttondownfcn',{@ax_KeyPressFcn,false})
    else
        maxVangle = max(vangle);
        if maxVangle > maxAmp, maxAmp = maxVangle; end
        countFocus = countFocus + 1;
        hAxFocus(countFocus) = handles.(strAxTag);
        ud = get(handles.(strAxTag),'userdata');
        ud.hFigParent = handles.output;
        ud.t = t;
        ud.strJointCamelCase = strJointCamelCase;
        ud.vangle = vangle;
        [indThisFirstMove,ud.absSmoothAngularRate] = findfirstmovefromangle(vangle,fs,iVisStim,timeToReact);
        if isempty(indThisFirstMove)
            indThisFirstMove = iVisStim + timeToReact*fs; % min react time 
        end
        if maxVangle == maxAmp
            indFirstMove = indThisFirstMove;
        end
        set(handles.(strAxTag),'userdata',ud);
        set(handles.(strAxTag),'buttondownfcn',{@ax_KeyPressFcn,true})
    end

    % "Plot" angle data
    cla; % not needed if we had not used dummy data to build gui (but that helped, so keep this...)
    hx = plot(t,xangle,'r');
    set(hx,'tag',sprintf('x%02d',i),'vis','off');
    handles.(sprintf('x%02d',i)) = hx;
    hy = plot(t,yangle,'g');
    set(hy,'tag',sprintf('y%02d',i),'vis','off');
    handles.(sprintf('y%02d',i)) = hy;
    hz = plot(t,zangle,'b');
    set(hz,'tag',sprintf('z%02d',i),'vis','off');
    handles.(sprintf('z%02d',i)) = hz;

    hv = plot(t,vangle,'k');
    set(hv,'tag',sprintf('v%02d',i),'vis','on');
    handles.(sprintf('v%02d',i)) = hv;
    axis('auto');

    % Get xyzv ylim
    ymini = min([min(xangle) min(yangle) min(zangle) min(vangle)]);
    ymaxi = max([max(xangle) max(yangle) max(zangle) max(vangle)]);
    yrngi = abs(ymaxi-ymini);
    if (ymini - 0.05*yrngi) < yminFM
       yminFM = ymini - 0.05*yrngi;
    end
    if (ymaxi - 0.05*yrngi) > ymaxFM
       ymaxFM = ymaxi + 0.05*yrngi;
    end
    
    % Plot event mark as vertical line
    hf = line(t(iEvt)*[1 1],[-22 22]);
    set(hf,'tag',sprintf('f%02d',i),'vis','on');
    set(hf,'color',0.66*[0.5 1 0.5]);
    handles.(sprintf('f%02d',i)) = hf;

    % Plot vis stim as dim vertical line
    hs = locAddVisStimLine(t,iVisStim);
    handles.(sprintf('s%02d',i)) = hs;

    % Set title
    set(handles.(sprintf('title%02d',i)),'interpreter','none');
    set(handles.(sprintf('title%02d',i)),'str',strJointCamelCase);

    hold off
end

% Set checkboxes for "V" and "F" and "S" to "checked"
set(handles.cbV,'Value',1);
set(handles.cbF,'Value',1);
set(handles.cbS,'Value',1);

% Set ylim (all subplots)
hAx = findobj(handles.fig,'-regexp','tag','ax\d{2}');
ylim = [0 1.01*max(ymax)];
set(hAx,'ylim',ylim);

% Set xlim (all subplots)
set(hAx,'xlim',[0 1.01*max(t)]);

% Get first motion line handles & link'em as draggable
hLinesFirstMove = findobj(handles.fig,'-regexp','tag','f\d{2}');
handles.hLink = linkprop(hLinesFirstMove,'Xdata');
ud = getsnapuserdata(t,ylim); % for "snap draggable" first motion lines
for j = 1:length(hLinesFirstMove)
    set(hLinesFirstMove(j),'xdata',t(indFirstMove)*[1 1],'ydata',ylim);
    set(hLinesFirstMove(j),'UserData',ud);
    draggable(hLinesFirstMove(j),'horizontal',@snapmotionfcn);
end

% Set initial value to autodetected; else NaN
handles.iFirstMove = indFirstMove; %NaN;
handles.originalFirstMotion = indFirstMove;

% Set vertical lines min/max y-values
hVlines = findobj(handles.fig,'-regexp','tag','^[fs]\d{2}$');
set(hVlines,'ydata',[yminFM ymaxFM]);

% Update guidata
handles.fs = fs;
handles.hLinesFirstMove = hLinesFirstMove;
guidata(handles.fig, handles);

%--------------------------------
function locGetFirstMove(handles)
% Update handles structure
xd = get(handles.f01,'xdata');
handles.iFirstMove = round((xd(1)+(1/handles.fs))*handles.fs);
guidata(handles.fig, handles);

% --- Executes on button press in pushbutton1.
function pbSaveFig_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
strMsg = sprintf('Note that this is trial #%d of %s, %s, then contact Ken or Krisanne for help.',999,'SUBJECT','SESSION');
uiwait(msgbox(strMsg,'Take note before we move on...','modal'));
uiwait(msgbox('HEY, STILL NEED GOOD "2DO.FIG" SAVE & TEMP LOG db TABLE','NOTE 4 KEN...','modal'));
handles.iFirstMove = NaN;
guidata(handles.fig,handles);
uiresume(handles.fig);

% --- Executes on button press in pushbutton1.
function pbOkayDone_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
locGetFirstMove(handles);
uiresume(handles.fig);

% --- Executes when user attempts to close fig.
function fig_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to fig (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hint: delete(hObject) closes the figure
uiwait(msgbox('Only close this fig using one of the GUI buttons.','Please close GUI via front-panel button.','modal'));

% --------------------------------------------------------------------
function menuOther_Callback(hObject, eventdata, handles)
% hObject    handle to menuOther (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% --------------------------------------------------------------------
function miRestoreOriginalFirstMotion_Callback(hObject, eventdata, handles)
% hObject    handle to miRestoreOriginalFirstMotion (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
ifm = handles.originalFirstMotion;
xd = get(handles.hLink.Targets(1),'xdata');
tCurrent = xd(1);
iCurrent = find(handles.t==tCurrent);
locUpdateFirstMove(iCurrent,ifm,handles);