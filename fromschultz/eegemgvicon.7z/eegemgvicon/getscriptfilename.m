function strFileFull = getscriptfilename(strDir,strExtension,strMove)
% getscriptfilename.m - returns filename for ev2 or s2s script
% 
% INPUTS
% strDir - string, directory to be written to, needs to be of the form in example
% strExtension - string, .ev2 [Neuroscan] or .s2s [Spike]
% strMove - string, movement being tested like 'pro' or 'sup
% 
% OUTPUTS
% strFileFull - string containing filename including full path
% 
% EXAMPLE
% strDir = 'S:\data\upper\eeg_emg_vicon\c1363plas\pre';
% strMove = 'pro';
% strFileEV2 = getscriptfilename(strDir,'.ev2',strMove);

% Author - Krisanne Litinas
% $Id$

% Corrects for if extension starts with [dot]
if strExtension(1) ~= '.'
    strExtension = ['.' strExtension];
end

if ispc
    strSplitter = '\';
else
    strSplitter = '/';
end

% Parse strDir to get relevant information
casDirParts = strsplit(strSplitter,strDir);
strSession = casDirParts{end};
strSubject = casDirParts{end-1};
strTest = casDirParts{end-2};  % should be eeg_emg_vicon
if strcmp(strTest,'eeg_emg_vicon')
    strTest = 'eev_wrist'; % need strTask too
end

% If strMove defined, include it.  If not, don't.
if exist('strMove','var')
    strFileName = [strSubject,'_',strTest,'_',strMove,'_',strSession,strExtension];
else
    strFileName = [strSubject,'_',strTest,'_',strSession,strExtension];
end
strFileFull = fullfile(strDir,strFileName);