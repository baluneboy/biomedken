function trydiffthresh(y,vThresh,trialBounds,strFile,strMovement)
% trydiffthresh.m
%
% INPUTS
% y - vector
% vThresh - column vector of different thresholds to try
% trialBounds - vector specifying start and end indicies; if not specified plots all of y
%
% EXAMPLE
% trydiffthresh(y,1)
% trydiffthresh(y,[6 30 40])
% trydiffthresh(y,[6 30 40],[580 850])


% Invert if movement is pronation
if strcmp(strMovement,'pro')
    y = -y;
end

% Account for trialBounds if not specified
if nargin < 3
    trialBounds = [1 length(y)];
end
y = y(trialBounds(1):trialBounds(2));


% Get filtered velocity and plot it
v = filtdydt(y,5,2,100,'low');

h = figure;
hv = plot(v,'k');
hax = gca;
hLims = get(hax,'ylim');
hold on

casColor = {'r';'g';'bl';'cy'};
for i = 1:length(vThresh)
    strColor = casColor{i};
    thresh = vThresh(i);
    iBreach = find(v > thresh, 1);
    if isempty(iBreach)
        warning('daly:eegemgvicon','warning, nothing found above thresh %d for %s',thresh,strFile)
        continue
    end
    
    yCursorPlot = hLims(1):hLims(end);
    xCursorPlot = repmat(iBreach,1,numel(yCursorPlot));
    hCursor = plot(xCursorPlot,yCursorPlot,strColor,'LineWidth',1.5);
    draggable(hCursor,'horizontal')
    
    strTrial = basename(strFile);
    hTitle = title([strTrial ' (move = ' strMovement ')']);
    set(hTitle,'interpreter','none');
end

% Plot threshhold for plausable reaction time
xThreshLow = repmat(15,1,numel(yCursorPlot));
xThreshHigh = repmat(25,1,numel(yCursorPlot));
hThreshLow = plot(xThreshLow,yCursorPlot,'--');
hThreshHigh = plot(xThreshHigh,yCursorPlot,'--');



if nargin > 3
    strFig = strrep(strFile,'.csv','.fig');
    strPDF = strrep(strFile,'.csv','.pdf');
   
    hgsave(strFig)
    set(h,'paperposition',[0.5 0.5 7.5 10])
    print(h,'-dpdf',strPDF)
end
    