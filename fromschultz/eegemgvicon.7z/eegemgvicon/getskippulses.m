function skippedPulses = getskippulses(skippedTrials)
% getskippulses.m - returns index of pulses to skip for a bad trial
% 
% INPUTS
% skippedTrials - row vector of skipped trials
% 
% OUTPUTS
% skippedPulses - nx2 matrix of pulses to skip, where n is number of skipped trials
% 
% NOTES
% Assumes two events [typically 1 50ms "go", 1 100ms "relax" pulse] per trial
% 
% EXAMPLE
% skippedTrials = [2 4]
% skippedPulses = getskippulses(skippedTrials)

% Author:  Krisanne Litinas $Id: getskippulses.m 4627 2010-02-16 19:27:49Z klitinas $

skippedPulses = zeros(2,numel(skippedTrials));
for i = 1:length(skippedTrials)
    trial = skippedTrials(i);
    skippedPulses(i,:) = [2*trial-1 2*trial];
end