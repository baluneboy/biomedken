function checknumpulsesinvicon(bounds,strFile)
% checknumpulsesinvicon - checks for two event pulses in vicon and errors
% out if there is a different number
%
% INPUTS
% bounds - numPulsesx2 matrix of pulse bounds, col1 is start of pulse, col2 is pulse end
% strFile - string, full file path of Vicon ascii file
%
% OUTPUTS
% none explicit, but errors out if number of pulses in file is not equal to 2
% 
% EXAMPLE
% bounds = [5 55; 60 160; 165 215];
% strFile = 'c:\temp\trash.csv';
% checknumpulsesinvicon(bounds,strFile);

% Author - Krisanne Litinas
% $Id$

% numEvtPulses = nRows(bounds);
pulseDurs = bounds(:,2) - bounds(:,1) + 1;
numFifty = numel(find(pulseDurs < 60));
switch numFifty
    case 1
        return
    case 2
        fprintf('%s%s','\n2 synch pulses found in %s, using first one',strFile)
    otherwise
        error('daly:eegemgvicon','error:should be 2 event pulses, %d pulses found in %s',numFifty,strFile)
end