function [iSpacebarEvent,h1,h2] = process_spacebar(z,strPlot,strKeyReleaseFile,strFile,i,memoryIssue)
% EXAMPLE
% iQue = process_spacebar(z)
% strPlot - 'suppress' to not plot, 'plotit' to show plot
%
% NOTES
% Assume one movement per vicon trial, only interested in first key press [movement cue]

if strcmpi(memoryIssue, 'hog')
    iSpacebarEvent = 1;
    kDiscrete = z;
else
    [iLow,iHigh] = getclusters(z,4);
    
    % some quick quantization here
    kDiscrete = ones(size(z));
    kDiscrete(iHigh) = 2;
    
    [stLo,durLo] = contig(kDiscrete,iLow);
    [stHi,durHi] = contig(kDiscrete,iHigh);
    
    % Try to determine sequence of space bar pulses
    if length(stLo) == 2 && length(stHi) == 3
        iSpacebarEvent = stHi(2);
    elseif stLo(1) < stHi(1)
        iSpacebarEvent = stHi(1);
    elseif length(stLo) == 1 && length(stHi) == 2
        disp('Only one key press found, using it for vis stim cue...')
        iSpacebarEvent = stHi(2);
    elseif length(stLo) == 3
        hLook = figure;
        plot(z)
        %     numStim = input('which key press cued vis stim? ');
        numStim = 2;
        iSpacebarEvent = stHi(numStim+1);
        close(hLook);
    else
        warning('warning:daly:eegemgvicon','unexpectedspacebarsequence')
        iSpacebarEvent = 1;
    end

end

switch strPlot
    case 'plotit' % User input on-the-fly
        h1 = subplot(211);
        plot(z)
        h2 = subplot(212);
        plot(kDiscrete);
        
        if exist(strKeyReleaseFile,'file')
            load(strKeyReleaseFile);
            ind = strfind(casAsciiFiles,strFile);
            iTrial = findnonemptycells(ind);
            if isnan(keyReleases(iTrial))
                blnCheck = 1;
            else
                blnCheck = 0;
                fprintf('\n%s%s%s\n','Detected existing manual check for ',strFile,'using that result');
            end
        else
            blnCheck = 1;
        end
                
        if blnCheck == 1      
            % Give user opportunity to override result
            strOK = input(sprintf('\n%s%s%s','iSpacebarEvent evaluated at ', num2str(iSpacebarEvent),'\n Need correction? '));
            if strcmpi(strOK,'yes')
                iSpacebarEvent = input('iSpacebarEvent = ','s');
                iSpacebarEvent = str2double(iSpacebarEvent);
            end
        else
            iSpacebarEvent = keyReleases(iTrial);
        end
        

    case 'cycle' % cycle through entire session's worth of trials
        h = figure;
        h1 = axes;
        hZ = plot(demean(z));
        hold on
        
        if ~strcmpi(memoryIssue,'hog')
            hD = plot(kDiscrete,'--r');
            set(hD,'linewidth',3)
        end
        padborder(gca,10)
        
        yLims = get(gca,'YLim');
        hKeyPoint = plot([iSpacebarEvent iSpacebarEvent],yLims,'k');
        set(hKeyPoint,'linewidth',2)
        [strPath,strTrial] = fileparts(strFile);
        hTitle = title(strTrial);
        set(hTitle,'interpreter','none');
        set(hTitle,'tag','axisTitle')
        
        % Plot cursor and make it draggable
        strTag = ['dragCursor_',num2str(i)];
        set(hKeyPoint,'tag',strTag)
        draggable(hKeyPoint,'horizontal')
        
    case 'supress' % No output plots
        return
end