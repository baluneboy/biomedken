function lineNum = eevgetcsvlinenum(strLine,c)
% eevgetcsvlinenum.m - finds line number of a given trial's data
% 
% INPUTS
% strLine - string, line data
% c - cell array, csv data read as string
% 
% OUTPUTS
% lineNum - double, line number of csv corresponding to trial of strLine
% 
% EXAMPLE
% lineNum = eevgetcsvlinenum(strLine,c);

% Author - Krisanne Litinas
% $Id$

casRepeatLine = repmat({strLine},length(c),1);
cRows = cellfun(@findstr,casRepeatLine,c,'uni',false);
lineNum = findnonemptycells(cRows);