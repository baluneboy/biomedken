function [casMoves,trialBoundsStart,trialBoundsEnd,synchPulses,iFirstMoves,iFirstMovesAbsolutes] = processviconfiles(strBaseDir,casAsciiFiles,skippedTrials,supDelay, proDelay,iSup,iPro,extraSynchs)
% processviconfiles - processes each vicon ascii file for eev analysis
% 
% INPUTS
% strBaseDir - directory results stored
% casAsciiFiles - cell array of strings containing Vicon ascii file names
% skippedTrials - vector of trial numbers to skip
% supDelay - vector containing vis stim delays for supination trials
% proDelay - vector containing vis stim delays for pronation trials
% iSup - index of supination
% iPro - index of pronation
% 
% OUTPUTS
% casMoves - nx1 cell array of move names like 'pro' or 'sup' [n = numTrials]
% trialBoundsStart - nx1 vector of start indices in vicon file
% trialBoundsEnd - nx1 vector of end indices in vicon file
% synchPulses - nx1 vector of synch pulse indices in vicon file
% iFirstMoves - nx1 vector of indices of first moves [relative to trialBoundStart]
% iFirstMovesAbsolutes - nx1 vector of indices of first move relative to
%   start of vicon file [this one is actually used]
% 
% EXAMPLE
% [casMoves,trialBoundsStart,trialBoundsEnd,synchPulses,iFirstMoves,iFirstMovesAbsolutes] = processviconfiles(strBaseDir,casAsciiFiles,skippedTrials,supDelay, proDelay,iSup,iPro);

% Author - Krisanne Litinas
% $Id$

%% Initialize variables
numTrials = length(casAsciiFiles);
casMoves = cell(numTrials,1);
trialBoundsStart = nan(numTrials,1);
trialBoundsEnd = nan(numTrials,1);
synchPulses = nan(numTrials,1);
iFirstMoves = nan(numTrials,1);
iFirstMovesAbsolutes = nan(numTrials,1);

% Find key release mat file and load keyRelease variable if found
strKeyReleaseFile = fullfile(fileparts(casAsciiFiles{1}),'key_releases_all.mat');

if exist(strKeyReleaseFile,'file')
    load(strKeyReleaseFile,'keyReleases','casAsciiFilesSaved');
else 
    keyReleases = ones(numTrials,1);
    fprintf('\n%s\n','No key release file found, using entire duration of Vicon trials......')
end
    

%% Loop through Vicon csv files
for i = 1:numTrials
    strFile = casAsciiFiles{i};
    numTrial = trialnumfromviconfilename(strFile);
    if find(skippedTrials==numTrial)
        fprintf('\nSkipping analysis on %s',strFile)
        continue
    end
    
    % Read csv file exported from Nexus
    sBatch = viconasciiread(strFile,0);
        
    %% Find [Vicon] index of 'first-motion' event synch pulse
    iEvt = findnonemptycells(strfind(sBatch.casAnalogLabels,'evt'));
    evt = sBatch.analogData(:,iEvt);
    evtBounds = getpulsebounds(evt,4.5);
    
    %% Check for correct number of [cherry] pulses in file [should be 2]
    checknumpulsesinvicon(evtBounds,strFile)
    
    %% Find [Vicon] index of keyboard key release within vicon trial
    sKinematics = mat2struct(sBatch.trialData,sBatch.casLabels);
    
if exist(strKeyReleaseFile,'file')
    iKeyLine = strmatch(strFile,casAsciiFilesSaved);
    iKeyRelease = keyReleases(iKeyLine);
else
    iKeyRelease = 1;
end
    close all;
    
    %% Find trialbounds based on stim delay, key release, and event bounds
    % Determine movement [pro/sup] and grab laptop display delay for this
    [stimDelay,strMovement] = detect_vis_stim_move(strFile,iSup,iPro,supDelay,proDelay,i);
    casMoves{i} = strMovement;
    iStimDelayVicon = stimDelay*0.001*sBatch.samplingRate;  % Divide by 1000 to get msec
    startTrialVicon = floor(iKeyRelease+iStimDelayVicon);
    endTrialVicon = floor(evtBounds(2,2) * (sBatch.samplingRate/sBatch.analogFreq));
    viconBounds = [startTrialVicon endTrialVicon];
    
    %% Get index of first motion [y-angle of wheel]
    thresh = 1;
    [hAxTrial,iFirstMove] = firstmotionplots(sKinematics.yangleWheel,thresh,viconBounds,strFile,strMovement,i);
    iFirstMoveAbsolute = startTrialVicon + iFirstMove;
    [H,strFigure,strPDF] = getcurrentplotset(strBaseDir,'wheel_position_velocity');
    numExistingPlots = getnumexistingsubplots(H);
    numNewPlot = numExistingPlots+1;
    hAxDest = subplot(3,2,numNewPlot);
    copyaxchildren(hAxTrial,hAxDest);
    H = gcf;
    synchPulse = evtBounds(1,1);
    
    %% Upsample vicon output
    factorUpsample = sBatch.analogFreq / sBatch.samplingRate;
    trialBoundsResampled = viconBounds * factorUpsample;
    iFirstMoveResampled = iFirstMove * factorUpsample;
    iFirstMoveAbsoluteResampled = iFirstMoveAbsolute * factorUpsample;
    
    %% Write trial info to structure and save it to figure using guidata
    trialBoundsStart(i) = trialBoundsResampled(1);
    trialBoundsEnd(i) = trialBoundsResampled(2);
    synchPulses(i) = synchPulse;
    iFirstMoves(i) = iFirstMoveResampled;
    iFirstMovesAbsolutes(i) = iFirstMoveAbsoluteResampled;
    
    strField = numtoword(numNewPlot);
    s.(strField).strMovement = strMovement;
    s.(strField).synchPulse = evtBounds(1,1);
    s.(strField).name = basename(strFile);
    s.(strField).iFirstMoveAbsolute = iFirstMoveAbsoluteResampled;
    s.(strField).trialBoundsStart = trialBoundsStart(i);
    s.(strField).trialBoundsEnd = trialBoundsEnd(i);
    s.(strField).iFirstMove = iFirstMoveResampled;
    guidata(H,s)
    hgsave(H,strFigure)
    
    %% If it's the sixth subplot of the very last trial, save the figure and print to pdf
    if numNewPlot == 6 || i == length(casAsciiFiles)
        eevsavesubplots(H,strPDF,strFigure)
    end
    
end