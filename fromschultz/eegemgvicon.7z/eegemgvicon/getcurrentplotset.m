function [H,strFigure,strPDF] = getcurrentplotset(strDir,strPrefix)
% getcurrentplotset.m
% 
% INPUTS
% strDir - directory containing plots
% strPrefix - naming convention for figures
% 
% OUTPUTS
% H - figure to be written to
% 
% EXAMPLE
% strDir = 'S:\data\upper\eeg_emg_vicon\c1363plas\pre';
% strPrefix = 'wheel_position_velocity';
% H = getcurrentplotset(strDir,strPrefix);

% Check existance of directory
if ~exist(strDir,'dir')
    error('daly:eegemgvicon','error: Directory %s does not exist',strDir);
end

% Grab any figure files [.pdf] and numbering that already exist
strPDFPattern = [strPrefix '\D*(?<num>\d{1,3})\.pdf$'];
strDotFigPattern = strrep(strPDFPattern,'.pdf','.fig');
casPDFs = getpatternfiles(strPDFPattern,strDir,'cas');
casDotFigs = getpatternfiles(strDotFigPattern,strDir,'cas');

if isempty(casPDFs)
%     trialNum = 1;
%     dotFigNum = 1;
    numFig = 1;
    numPDF = 1;
else
    [ignoreOne,iSort] = sortcasfiles(casPDFs,strPrefix);
    iSort = sort(iSort);
    numPDF = iSort(end);
    [ignoreTwo,iDotFig] = sortcasfiles(casDotFigs,strPrefix);
    iDotFig = sort(iDotFig);
    numFig = iDotFig(end);
end
strFigure = fullfile(strDir,[strPrefix,'_',num2str(numFig),'.fig']);
strPDF = strrep(strFigure,'.fig','.pdf');

% Load figure if it already exists
if ~exist(strPDF,'file') && exist(strFigure,'file')
%     H = figure;
    H = hgload(strFigure);
else % increment fig file num
    H = figure;
    if ~isempty(casDotFigs)
        strFigure = fullfile(strDir,[strPrefix,'_',num2str(numFig+1),'.fig']);
        strPDF = strrep(strFigure,'.fig','.pdf');
    end
end