function [evtData,fs] = geteegevt(strFile)
% geteegevt.m - returns event marker channel data and sampling rate found in EEG .cnt file
% 
% EXAMPLE
% strFile = 'S:\data\upper\eeg_emg_vicon\c1363plas\pre\eeg\wrist.cnt';
% [evtEEG,fsEEG] = geteegevt(strFile);

% Author - Krisanne Litinas
% $Id: geteegevt.m 4627 2010-02-16 19:27:49Z klitinas $

% Read cnt file, look for event channel
cnt = mod_eeg_load_scan4_cnt(strFile,1,[1 10]);
casLabels = cnt.labels;
evt_cnum = find(ismember(lower(casLabels),'evt'));

% Grab event channel data and sampling rate
cnt = mod_eeg_load_scan4_cnt(strFile,evt_cnum,'all');
fs = cnt.srate;
evtData = cnt.volt;