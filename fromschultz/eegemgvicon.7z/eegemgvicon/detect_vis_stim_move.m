function [stimDelay,strMovement] = detect_vis_stim_move(strFile,iSup,iPro,supDelay,proDelay,i)
% detect_pro_or_sup.m
% 
% EXAMPLE
% [stimDelay,strMovement] = detect_vis_stim_move(strFile,iSup,iPro,supDelay,proDelay,i)

% Author - Krisanne Litinas $Id: detect_vis_stim_move.m 4627 2010-02-16 19:27:49Z klitinas $

% Detect whether this file is supination or pronation
iLaptopDomain = 2*i - 1;
blnIsSup = ~isempty(find(iSup == iLaptopDomain, 1));
blnIsPro = ~isempty(find(iPro == iLaptopDomain, 1));

% Error check [should have just one movement per file
sumBlnMovements = blnIsSup + blnIsPro; % should be 1
switch sumBlnMovements
    case 0
        error('daly:eegemgvicon','error:no corresponding laptop index for %s',strFile)
    case 2
        error('daly:eegemgvicon','error:index corresponds for both pro and sup for %s',strFile)
end

if blnIsSup == 1
    iLaptopPulse = iSup;
    fprintf('\nProcessing %s as supination', strFile)
    visDelay = supDelay;
    strMovement = 'sup';
else
    iLaptopPulse = iPro;
    fprintf('\nProcessing %s as pronation', strFile)
    visDelay = proDelay;
    strMovement = 'pro';
end

% Grab laptop display delay for this trial
iThisTrial = iLaptopPulse == iLaptopDomain;
stimDelay = visDelay(iThisTrial);