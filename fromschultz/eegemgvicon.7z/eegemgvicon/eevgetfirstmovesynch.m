function [iFirstMoveToSynch,numTrial,strMove,numTrialGood] = eevgetfirstmovesynch(str,skippedTrials)
% eevgetfirstmovesynch.m - gets index of first motion relative to synch pulse for given vicon trial
% 
% INPUTS
% str - string containing the following [comma delimited]
%   - strTrial
%   - strMove
%   - iViconStart
%   - iViconEnd
%   - iSynchPulse
%   - iFirstMove
%   - iFirstMoveAbsolute
% 
% skippedTrials - vector containing numbers of trials to skip
% 
% 
% OUTPUTS
% iFirstMoveToSynch - calculated vicon first motion relative to vicon synch pulse
% numTrial - trial number based on trial name
% strMove - string, example 'pro' or 'sup'
% numTrialGood - "good" trial number [e.g. if trial 3 is bad, trial 4 is
%                  actually the third "good" trial
% 
% EXAMPLE
% iSynch = eevgetfirstmovesynch(str);
% [iFirstMoveToSynch,numTrial,strMove,numTrialGood] = eevgetfirstmovesynch(str,skippedTrials)';

% Author - Krisanne Litinas
% $Id: eevgetfirstmovesynch.m 4627 2010-02-16 19:27:49Z klitinas $

% Parse string to cell array
cas = strsplit(',',str);

% Now parse the cas
strTrial = cas{1};
strMove = cas{2};
iSynchPulse = str2double(cas{5});
iFirstMoveAbs = str2double(cas{7});

iFirstMoveToSynch = iFirstMoveAbs - iSynchPulse;

% Get numGoodTrial
cNumTrial = regexp(strTrial,'\d+','match');
strNumTrial = cNumTrial{1};
numTrial = str2double(strNumTrial);

if ~ismember(numTrial,skippedTrials) % not a skip
    congeal = [skippedTrials numTrial];
    sortedSkipsTrial = sort(congeal,'ascend');
    iTrialFall = find(sortedSkipsTrial == numTrial);
    numSkipsPreceeding = iTrialFall - 1;
    numTrialGood = numTrial + numSkipsPreceeding;
else % a skip
    numTrialGood = [];
end

