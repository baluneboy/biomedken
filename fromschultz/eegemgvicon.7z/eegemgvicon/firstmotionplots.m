function [hAx,iFirstMove] = firstmotionplots(y,thresh,trialBounds,strFile,strMovement,i)
% firstmotionplots.m
%
% INPUTS
% y - vector
% thresh - threshold to define first motion
% trialBounds - vector specifying start and end indicies; if not specified plots all of y
% strFile - name of vicon ascii file for this trial
% strMovement - 'pro' or 'sup', task name
%
% EXAMPLE
% firstmotionplots(y,1)
% firstmotionplots(y,[6 30 40])
% [hAx,iFirstMove] = firstmotionplots(y,thresh,trialBounds,strFile,strMovement,i)

% Author - Krisanne Litinas
% $Id: firstmotionplots.m 5752 2010-08-06 14:05:30Z klitinas $

% Invert if movement is pronation
if strcmp(strMovement,'pro')
    y = -y;
end

% Account for trialBounds if not specified
if nargin < 3
    trialBounds = [1 length(y)];
end
y = y(trialBounds(1):trialBounds(2));


% Get filtered velocity and plot it
v = filtdydt(y,5,2,100,'low');

h = figure;
hAx = axes;

% Plot wheel angular velocity
hv = plot(v,'k','linewidth',1.5);
hold on

% Plot wheel angle
hy = plot(y,'--k','linewidth',1.5);
hax = gca;
hLims = get(hax,'ylim');

% Warns if no movement above threshold is found
iBreach = find(v > thresh, 1);
if isempty(iBreach)
    warning('daly:eegemgvicon','warning, nothing found above thresh %d for %s',thresh,strFile)
end

yCursorPlot = hLims(1):hLims(end);
xCursorPlot = repmat(iBreach,1,numel(yCursorPlot));

strTrial = basename(strFile);
hTitle = title([strTrial ' (move = ' strMovement ')']);
set(hTitle,'interpreter','none');
set(hTitle,'tag','axisTitle')

% Plot threshhold for plausable reaction time
xThreshLow = repmat(15,1,numel(yCursorPlot));
xThreshHigh = repmat(25,1,numel(yCursorPlot));
hThreshLow = plot(xThreshLow,yCursorPlot,'--');
hThreshHigh = plot(xThreshHigh,yCursorPlot,'--');

% Plot cursor and make it draggable
if isempty(xCursorPlot)
    xCursorPlot = repmat(25,1,numel(yCursorPlot));
end
    
hCursor = plot(xCursorPlot,yCursorPlot,'g','LineWidth',2.5);
strTag = ['dragCursor_',num2str(i)];
set(hCursor,'tag',strTag)
draggable(hCursor,'horizontal')

% Questionable, maybe motion detected before humanly possible (terms of human rxn time)
if unique(xCursorPlot) < unique(xThreshHigh)
    set(hCursor,'Color','r')
end

% Apply legend
hHandles = [hy hv];
hLegend = legend(hHandles,'Position (angle)','Angular Velocity');


% Save figure and pdf
if nargin > 3
    strFig = strrep(strFile,'.csv','.fig');
    strPDF = strrep(strFile,'.csv','.pdf');
    
    hgsave(strFig)
    set(h,'paperposition',[0.5 0.5 7.5 10])
    print(h,'-dpdf',strPDF)
end

% Return index of first motion via cursor position
hCursorXData = get(hCursor,'xdata');
iFirstMove = round(unique(hCursorXData));
