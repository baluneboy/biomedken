function rig2buildgui
HX = nan*ones(18,1);
HY = nan*ones(18,1);
HZ = nan*ones(18,1);
HV = nan*ones(18,1);
HF = nan*ones(18,1);
for i = 1:18
    hax = findobj(gcf,'tag',sprintf('ax%02d',i));
    axes(hax);
    axTag = get(hax,'tag');
    ht = get(gca,'title');
    titleStr = get(ht,'str');
    titleTag = get(ht,'tag');
    hold on
    x = 1:3;
    y = 4:6;
    z = 3:-1:1;
    HX(i) = plot(1:3,1:3,'r'); %xangle
    set(HX(i),'tag',sprintf('x%02d',i));
    HY(i) = plot(1:3,4:6,'g');
    set(HY(i),'tag',sprintf('y%02d',i));
    HZ(i) = plot(1:3,3:-1:1,'b');
    set(HZ(i),'tag',sprintf('z%02d',i));
    HV(i) = plot(1:3,anglevecsum(x,y,z),'m'); %vangle AFTER DETRENDING
    set(HV(i),'tag',sprintf('v%02d',i));
    
    % Plot event mark as vertical line
    HF(i) = line([2 2],[-180 180],'color',0.66*[1 1 1]);
    set(HF(i),'tag',sprintf('f%02d',i));
    set(gca,'xlim',[0 4],'ylim',[-10 10]);
    set(gca,'tag',axTag);
    set(ht,'str',titleStr);
    set(ht,'tag',titleTag);
    hold off
end