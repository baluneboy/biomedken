function iSkips = countbadevents(skippedTrials,strViconDir)
% countbadevents.m - for skipped trials, returns any events that were hit and present in EEG and EMG datasets
% 
% INPUTS
% skippedTrials - vector containing trial numbers skipped
% 
% OUTPUTS
% iSkips - index of 50ms pulses to skip
% 
% EXAMPLE
% skippedTrials = [60 63];
% iSkips = countbadevents(skippedTrials);

% Author - Krisanne Litinas
% $Id: countbadevents.m 4627 2010-02-16 19:27:49Z klitinas $

% Loop through all skipped trials
for i = 1:length(skippedTrial)
    numTrial = skippedTrials(i);
    strPattern = [numTrial '.csv$'];
    casViconFile = getpatternfiles(strPattern,strViconDir,'cas');
    numCSVs = length(casViconFiles);
    
    % Check for number of matched CSVs
    if numCSVs == 1
        strViconFile = casViconFile{1};
    else
        error('error:daly:eegemgvicon','Error, should only be 1 csv file for skipped trial %d, there are %d present',numTrial,numCSVs);
    end
    
    % Try reading the vicon file [is it blank?]
    try
        s = viconasciiread(strViconFile);
    end
    
    % If it's not a dummy file, s exists.  Check for number of pulses
    if exist('s','var')
        iEvt = findnonemptycells(strfind(s.casAnalogLabels,'evt'));
        evt = s.analogData(:,iEvt);
        evtBounds = getpulsebounds(evt,4.5);
        numPulses = nRows(evtBounds);
        fprintf('Found %d events in skipped trial %d',numPulses,numTrial)
    else
        % Dummy file, no pulses present
        numPulses = 0;
    end
end
        