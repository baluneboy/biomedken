function hLinesVis = set_ylim_visible(hFig,strTagPat)
% EXAMPLE
% strTagPat = '^[xyzvr]\d{2}$';
% set_ylim_visible(hFig,strTagPat);

%% Get matching tagged objects that are lines
hTag = findobj(hFig,'-regexp','tag',strTagPat);
hVis = findobj(hFig,'vis','on');
hLines = findobj(hFig,'type','line');
hTagVis = intersect(hTag,hVis);
hLinesVis = intersect(hTagVis,hLines);

%% Get ydata for each
if length(hLinesVis)==1
    Y = get(hLinesVis,'ydata');
    hAx = get(hLinesVis,'parent');
elseif length(hLinesVis)>1
    Y = cell2mat(get(hLinesVis,'ydata'));
    hAx = unique(cell2mat(get(hLinesVis,'parent')));
else
    return
end
ymin = min(Y(:));
ymax = max(Y(:));
yrange = abs(ymax-ymin);
ymin = ymin - 0.05*yrange;
ymax = ymax + 0.05*yrange;

%% Set ylim of parent axes for "unique" axes (not each)
set(hAx,'ylim',[ymin ymax]);