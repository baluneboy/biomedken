function [strTestedArm,strDateTested] = queryeevsession(strSubject,strSession,strHost,strTask)
% QUERYEEVSESSION get some basic session info from database
%
% INPUTS:
% strSubject - string for subject
% strSession - string for session ('pre' or 'post')
% strHost - string for db host (typically 'schultz')
%
% OUTPUTS:
% strTestedArm - string for tested arm
% strDateTested - string for date
%
% EXAMPLE
% strHost = 'schultz';
% strSubject = 'c1363plas';
% strSession = 'pre';
% [strTestedArm,strDateTested] = queryeevsession(strSubject,strSession,strHost);

% Author: Ken Hrovat, Krisanne Litinas
% $Id: queryeevsession.m 4627 2010-02-16 19:27:49Z klitinas $

% Get db hostname
if nargin == 2
    strHost = 'Schultz';
end

fprintf('\nDoing daly db query on %s for eev session info....',strHost)

% Do query on subject and date_scanned
strQuery = 'SELECT subject,tested_arm,session,date_tested ';
strQuery = [strQuery 'FROM eevsession '];
strQuery = [strQuery 'WHERE subject = "' strSubject '" and session = "' strSession '" and task = "' strTask '"'];
foo = mym('open', strHost, 'klitinas', 'mpw4mysql');
foo = mym('use','daly');
r = mym(strQuery);
mym('close');

fprintf('\b done.\n%s',repmat('~',1,42))

% Verify one record returned
if length(r.subject) ~= 1
    fprintf('\nProblem with query results for "%s"',strQuery)
    error('daly:eegemgvicon:unexpectedCount','record count not one for query of subject & date_scanned');
end
strTestedArm = r.tested_arm{:};
strDateTested = r.date_tested{:};

% Show info we found
fprintf('\n   subject: %s',strSubject)
fprintf('\n   session: %s',strSession)
fprintf('\n   date_tested: %s',strDateTested)
fprintf('\n   tested_arm: %s',strTestedArm);
fprintf('\n')

