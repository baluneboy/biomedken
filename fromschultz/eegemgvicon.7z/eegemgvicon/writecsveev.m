function writecsveev(strFile,s)
% writecsveev.m - given structure containing appropriate data, writes it to
% csv file in 'Vicon-output format'
% 
% INPUTS
% strFile - string, full filename of csv to be created
% s - structure containing fields
%   samplingRate
%   casLabels
%   analogData
%   casAnalogLabels
%   analogFreq
%   trialData
%   offset
% 
% OUTPUTS
% [implicit]:  csv file with name of strFile containing data in structure s
% in Vicon-output format
% 
% EXAMPLE
% strFileOrig = 'S:\data\upper\vicon\dalyUE\upperStroke\s1360plas\20090401_s1360plas\sup_pro_batch04.csv';
% s = viconasciiread(strFileOrig,0);
% strFileNew = 'c:\temp\testcsv.csv';
% writecsveev(strFileNew,s)

% Author - Krisanne Litinas
% $Id$

% Open file to write to
fid = fopen(strFile,'w');

% Write trajectory header
fprintf(fid,'\n\n\n');
fprintf(fid,'%s\n','TRAJECTORIES');
fprintf(fid,'%d,%s\n',s.samplingRate,'hz');


% Format trajectory labels [output as 'strLabelsAll]
casUniqueLabels = s.casLabels(2:3:end-2);
strLabelsAll = '';
for i = 1:length(casUniqueLabels)
    str = casUniqueLabels{i};
    str = str(2:end);
    if i == length(casUniqueLabels)
        str = str;
    else
        str = [str ',,,'];
    end
    casUniqueLabels{i} = str;
    strLabelsAll = [strLabelsAll str];
end
strLabelsAll = [',' strLabelsAll];
fprintf(fid,'%s\n',strLabelsAll);

% Format 'xyz' row and write to file
strXYZ = repmat('X,Y,Z,',1,(length(s.casLabels)-1)/3);
strXYZ = strXYZ(1:end-1);
strXYZ = ['Field #,' strXYZ];
fprintf(fid,'%s\n',strXYZ);

% Write trajectory data [row-by-row]
numColsData = nCols(s.trialData);
strFmtTrialData = ['%d,' repmat('%0.4f,',1,numColsData-1),'\n'];
for i = 1:nRows(s.trialData)
    fprintf(fid,strFmtTrialData,s.trialData(i,:));
end

% Write analog header
fprintf(fid,'\n%s\n','ANALOG');
fprintf(fid,'%d,%s\n',s.analogFreq,'hz');
fprintf(fid,'%s,%d\n','Sample #',1);
fprintf(fid,'%s,%s\n','Units:','V');

% Write analog data [row-by-row]
strFmtAnalogData = '%d,%0.5f\n';
for i = 1:nRows(s.analogData)
    fprintf(fid,strFmtAnalogData,s.analogData(i,:));
end

% Close file
fclose(fid);
