function eevcsvsplice(strFile)
% eevcsvsplice.m - reads csv file from [older convention] batch of 5/10
% movements that we used to do in EEV collection and separates them out
% into individual csv files.
% 
% INPUTS
% strFile - string, full filename of csv ascii file that was output from
% a Vicon trial containing a batch of moves.  The file must contain Vicon
% trajectories and analog data, which contains the event marker
% 
% OUTPUTS
% [implicit]:  csv files, one for each move in a batch, located in same
% directory as strFile
% 
% EXAMPLE
% strFile = 'S:\data\upper\vicon\dalyUE\upperStroke\s1360plas\20090401_s1360plas\sup_pro_batch04.csv';
% eevcsvsplice(strFile)

% Author - Krisanne Litinas
% $Id$

% Read csv file exported from Nexus
sBatch = viconasciiread(strFile,0);
strPath = fileparts(strFile);
strPattern = 'supination_pronation(?<num>\d{2,3}).csv';

% Find [Vicon] index of 'first-motion' event synch pulse and count the number found
iEvt = findnonemptycells(strfind(sBatch.casAnalogLabels,'evt'));
evt = sBatch.analogData(:,iEvt);
evtBounds = getpulsebounds(evt,4.5);
numPulses = length(evtBounds);

% Plot event mark channel and allow user to skip extra pulses
if length(evtBounds) ~= 20
    fprintf('\n%d%s\n',numPulses,' found, any extra?');
    h = figure;
    plot(evt)
    iSkip = input('Enter pulse num to skip or press enter to keep all: ');
    if ~isempty(iSkip)
        evtBounds(iSkip,:) = [];
    end
    close(h)
end

% Calculate duration of pulses and get indices of 100ms ones
evtDurs = evtBounds(:,2) - evtBounds(:,1);
evtHundred = evtDurs > 75;
iHundred = evtBounds(evtHundred,1);

% Loop through each 100ms pulse
for i = 1:length(iHundred)
    
    % Get beginning and end of trial based on preceding 100ms pulse [plus
    % 150ms buffer] and current 100ms pulse
    if i == 1 % first trial
        iBegin = 1;
    else
        iBegin = iHundred(i-1) + 151;
    end
    iEnd = iHundred(i) + 150;
    trialBoundsEvt = [iBegin iEnd];
    
    % Downsample [probably factor of 10] to get the trial bounds in Vicon freq points
    downsampleFactor = sBatch.analogFreq / sBatch.samplingRate;
    trialBoundsVicon = round(trialBoundsEvt ./ downsampleFactor);
    
    if trialBoundsVicon(1) == 0
        trialBoundsVicon(1) = 1;
    end
    
    % Call local function to get structure with only one trial's worth of data
    sNew = locsplicebatch(sBatch,trialBoundsEvt,trialBoundsVicon);
    
    % Find already-existing trial csv files and increment trial name by 1
    casFilesExisting = getpatternfiles(strPattern,strPath,'cas');
    if isempty(casFilesExisting)
        strFileNew = fullfile(strPath,'supination_pronation001.csv');
    else
        strFileMostRecent = casFilesExisting(end);
        sMatch = regexpi(strFileMostRecent,strPattern,'names');
        numNewFile = str2double(sMatch{1,1}.num) + 1;
        strNewNum = num2str(numNewFile);
        
        % We do this because want "supination_pronation001.csv", not "supination_pronation1.csv"
        switch length(strNewNum)
            case 1
                strNewNum = ['00' strNewNum];
            case 2
                strNewNum = ['0' strNewNum];
        end
        
        strFileNew = fullfile(strPath,['supination_pronation' strNewNum '.csv']);
    end
    
    % Write new csv file for this trial
    writecsveev(strFileNew,sNew)
end

% ----------------------------------------------------
function sNew = locsplicebatch(s,boundsEvt,boundsVicon)

% First copy entire structure to new variable sNew
sNew = s;

% Splice event mark and vicon data fields according to their bounds
sNew.analogData = sNew.analogData(boundsEvt(1):boundsEvt(2),:);
sNew.trialData = sNew.trialData(boundsVicon(1):boundsVicon(2),:);

% Now the offset is greater than zero [unless it is the first trial in the c3d file]
sNew.offset = boundsVicon(1)-1;
