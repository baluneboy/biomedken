function eevrsynctodatapath(strSubject,strSession)
% eevrsynctodatapath.m - calls bash script to rsync eeg, emg, visstim and
% brainsight files from nightly_mirror to datapath on Schultz
% 
% INPUTS
% strSubject - string, subject code
% strSession - string, session name like 'pre' or 'post'
% 
% OUTPUTS
% [implicit] eeg, emg, vis_stim, and brainsight directories on datapath
% containing appropriate files
% 
% EXAMPLE
% eevrsynctodatapath('s1901tbis','pre')

% Author - Krisanne Litinas
% $Id$

strFileBashExe = getenv('strFileBashExe');  
if isempty(strFileBashExe)
    strFileBashExe = 'c:\cygwin\bin\bash.exe';
end

strBashPath = getenv('BASHPATH');
if isempty(strBashPath)
    strBashPath = 'C:\_workcopy\scripts\bash';
end

strScriptFile = fullfile(strBashPath,'rsync_eeg_emg_vicon.bash');
strCmd = [strFileBashExe ' -l ' strScriptFile ' ' strSubject ' ' strSession ' /cygdrive/s'];
fprintf('\n....Copying EEG, EMG, vis stim, and brainsight files to datapath....\n');
dos(strCmd);
fprintf('\n..........................................................\n') 