function eevfirstmoves(strSubject, strSession, strTask)
% eevfirstmoves.m - produces set of .fig and .pdf files containing
% per-trial plots of wheel position.  User then checks the .fig files and
% can manipulate a cursor to correct [if necessary] index of first move
%
% INPUTS
% strSubject - string, subject code
% strSession - string, 'pre' or 'post'
% strTask - string, name of task
%
% OUTPUTS
% [implicit] .pdf and .fig files containing wheel position and velocity
% plots for each trial
% 
% EXAMPLE
% strSubject = 'c1363plas';
% strSession = 'pre';
% strTask = 'supination_pronation';
% eevfirstmoves(strSubject, strSession, strTask);

% Author: Krisanne Litinas
% $Id: eevfirstmoves.m 6484 2010-12-23 13:35:28Z klitinas $

%% Rsync from nightly_mirror to data path on schultz
% eevrsynctodatapath(strSubject,strSession)

%% Get needed data paths
if exist('s:\','dir')
    [strViconDir, ignoreOne, ignoreTwo,strLaptopDir,strBaseDir] = geteevdirs(strSubject, strSession,strTask);
else 
    error('daly:eegemgvicon:invaliddir','Must have schultz mapped to S drive');
end

%% Query db to find skipped [Vicon] trials
[skippedTrials,extraSynchs,skippedStims] = queryeevskippedtrials(strSubject,strTask,strSession);

%% Load and process laptop display mat file
strDelayFile = getdelayfile(strLaptopDir,strTask);
if strcmpi(strTask,'supination_pronation')
    [supDelay,iSup,proDelay,iPro] = process_visual_display_delay(strDelayFile,skippedStims);
    iDelay = [iSup; iPro];
else
    [taskDelay,iDelay] = process_visual_display_delay(strDelayFile,skippedStims);
end

%% Find and sort all Vicon csv files
% casAsciiFiles = getpatternfiles('supination_pronation(?<num>\d{2,3}).csv',strViconDir,'cas'); % FIXME
strPatAscii = [strTask '(?<num>\d{2,3}).csv'];
casAsciiFiles = getpatternfiles(strPatAscii,strViconDir,'cas'); % FIXME
casAsciiFiles = sortcasfiles(casAsciiFiles,strTask);

%% Error check to see if number of csv files match with number of laptop pulses
checknumstims(iDelay,casAsciiFiles)

%% Loop through each vicon file
[casMoves,trialBoundsStart,trialBoundsEnd,synchPulses,iFirstMoves,iFirstMovesAbsolutes] = processviconfiles(strBaseDir,casAsciiFiles,skippedTrials,supDelay, proDelay,iSup,iPro,extraSynchs);

%% Write first motion results to csv file [for now]
strOutputCSV = fullfile(strBaseDir,'first_motion_index.csv');
append_first_move(strOutputCSV,casAsciiFiles,casMoves,trialBoundsStart,trialBoundsEnd,synchPulses,iFirstMoves,iFirstMovesAbsolutes);

%% Close any open figures
close all