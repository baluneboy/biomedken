function [indFirstMove,absSmoothAngularRate] = findfirstmovefromangle(angle,fs,iVisStim,timeToReact,strMethod)
% EXAMPLE
% load('g:\dropbox\ken\eevbcigui_withtangle.mat'); % gets "angle"
% fs = 100; % sa/sec sample rate
% % deltaPeak = 0.5; % works for now...but FIXME for robustness
% % t = gent(angle,fs);
% % t = 0:1/fs:length(angle)/fs-1/fs;
% iVisStim = 150;
% timeToReact = 150e-3;
% [indFirstMove,absSmoothAngularRate] = findfirstmovefromangle(angle,fs,iVisStim,timeToReact);
%
% subplot(2,1,1)
% plot(t,angle)
% axis([9.5 12.5 -1 59]);
% subplot(2,1,2)
% plot(t,absSmoothAngularRate)
% axis([9.5 12.5 -1 59]);
% hold on
% oa = axis;
% hLine = line(t(indFirstMove)*[1 1],[oa(3:4)]);
% set(hLine,'color','r');
% fprintf('\nFirst move at t = %.3f sec\n',t(indFirstMove))
% shg

%% Deal with inputs
if nargin==4
    strMethod = 'prewitt';
end

%% Get rising edges & note these should be just after first move candidates
[indRisingEdges,accel,absSmoothAngularRate] = risingedgedetector(angle,fs,strMethod);
if isempty(indRisingEdges)
    warning('daly:EEV:noEdgesFound','no "detectable" rising edges found');
    indFirstMove = [];
    return
end

%% Establish earliest possible move time
% FIXME error check that indEarliest "behaves well" (in expected range,etc)
numPtsToReact = timeToReact * fs;
indEarliest = iVisStim + numPtsToReact;

%% Get valleys (local mins)
[maxtab, mintab] = peakdet(absSmoothAngularRate); %,deltaPeak);
indValleys = mintab(:,1);

%% Loop over rising edges to screen first move candidates
indFirstMove = [];
for i = 1:length(indRisingEdges)
    indThisRisingEdge = indRisingEdges(i);
    iPrevious = find(indValleys<indThisRisingEdge,1,'last');
    % if this valley is at/beyond earliest possible time then we're done!
    if indValleys(iPrevious) >= indEarliest
        indFirstMove = indValleys(iPrevious);
        break;
    end
end