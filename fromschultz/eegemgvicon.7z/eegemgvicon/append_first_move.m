function append_first_move(strOutputCSV,casFiles,casMoves,trialBoundsStart,trialBoundsEnd,synchPulses,iFirstMoves,iFirstMovesAbsolutes)
% append_first_move.m - appends first motion information to output csv file
% 
% EXAMPLE
% append_first_move(strOutputCSV,casFiles,casMoves,trialBoundsStart,trialBoundsEnd,synchPulses,iFirstMoves,iFirstMovesAbsolutes)
% 
% Author - Krisanne Litinas
% $Id: append_first_move.m 4627 2010-02-16 19:27:49Z klitinas $

fid = fopen(strOutputCSV,'a');
strFmt = '\n%s,%s,%d,%d,%d,%d,%d';
for i = 1:length(casFiles)
    strFile = casFiles{i};
    strName = basename(strFile);
    strMove = casMoves{i};
    trialStart = trialBoundsStart(i);
    trialEnd = trialBoundsEnd(i);
    synchPulse = synchPulses(i);
    iFirstMove = iFirstMoves(i);
    iFirstMoveAbsolute = iFirstMovesAbsolutes(i);
    fprintf(fid,strFmt,strName,strMove,trialStart,trialEnd,synchPulse,iFirstMove,iFirstMoveAbsolute);
end
fclose(fid);