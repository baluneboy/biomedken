function insertrecordlogfirstmotion(strSchema,strTable,casFields,values)
% EXAMPLE
% strSchema = 'eevbci';
% strTable = 'logfirstmotion';
% casFields = {'subject','task','session','trial','detailed','original_index_firstmotion','unofficial_index_firstmotion'};
% values = {'nobby','trench','aftermath',765,1,1234,888};
% insertrecordlogfirstmotion(strSchema,strTable,casFields,values)

% Author: Ken Hrovat
% $Id$

%% Build statement
strQuery = sprintf('insert into %s.%s (%s,%s,%s,%s,%s,%s,%s) values ("%s","%s","%s",%d,%d,%d,%d);',...
    strSchema,strTable,...
    casFields{:},...
    values{:});

%% Establish connection
foo = mym('open', 'schultz', 'ken', 'mpw4mysql'); %#ok<NASGU>
foo = mym('use',strSchema); %#ok<NASGU>

%% Execute query
r = mym(strQuery); %#ok<NASGU>

%% Close connection
mym('close');