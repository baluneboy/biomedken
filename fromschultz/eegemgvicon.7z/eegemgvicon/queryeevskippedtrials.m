function [skipTrials,extraSynchs,extraVisStims] = queryeevskippedtrials(strSubject,strTask,strSession)
% queryeevskippedtrials.m - return trials to skip OR NaN if query fails OR [] if 'none' to skip
%
% INPUTS
% strSubject - string, name of subject
% strTask - string, name of task
% strSession - string, session name [pre, post, etc]
% 
% OUTPUTS
% skipTrials - 1xn vector containing n indices of skipped trials
% extraSynchs - 1xm vector containing m indices of extraneous synch pulses
% 
% EXAMPLE
% strSubject = 'c1363plas';
% strTask = 'supination_pronation';
% strSession = 'pre';
% skipTrials = queryeevskippedtrials(strSubject,strTask,strSession)
% [skipTrials, extraSynchs] = queryeevskippedtrials(strSubject,strTask,strSession)
% [skipTrials, extraSynchs,extraVisStims] = queryeevskippedtrials(strSubject,strTask,strSession)

% Author - Krisanne Litinas
% $Id: queryeevskippedtrials.m 5402 2010-06-11 20:23:21Z klitinas $

% Use evalc to hide mym messages
foo = mym('open', 'Schultz', 'klitinas', 'mpw4mysql');
foo = mym('use','daly');

% Construct and execute query based on number of inputs [right now only
% expects one, two, or three]
switch nargout
    case 1
        strQuery = 'SELECT s.subject,s.session,s.task,s.skipped_trials ';
    case 2
        strQuery = 'SELECT s.subject,s.session,s.task,s.skipped_trials,s.extra_synchs ';
    case 3
        strQuery = 'SELECT s.subject,s.session,s.task,s.skipped_trials,s.extra_synchs,s.extra_vis_stims ';
    otherwise
        error('daly:eegemgvicon:mysqlQueryFail','invalid number of database outputs requested');
end
strQuery = [strQuery 'FROM eevskiptrials s '];
strQuery = [strQuery 'WHERE s.subject = "' strSubject '" and s.session = "' strSession '" and s.task = "' strTask '"'];

a = mym(strQuery);

% Call local function to get skipped_trials
skipTrials = locgetdbresult(a,'skipped_trials');

% If second output requested, also get extraSynchs
if nargout > 1
    extraSynchs = locgetdbresult(a,'extra_synchs');
end

% If third output requested, also get extraVisStims
if nargout > 2
    extraVisStims = locgetdbresult(a,'extra_vis_stims');
end


mym('close'); % this mym command has no messages

% -------------------------------------
function m = locgetdbresult(a,strField)
% Takes output structure of query and returns row vector of results given a fieldname

str = char(a.(strField){:})';
if strcmp(str,'none')|| isempty(str)
    m = [];
% elseif isempty(str)
%     error('daly:eegemgvicon:mysqlQueryFail','could not find trials/events to skip for "%s" for "%s"',strSubject,strTask)
else
    m = sscanf(str,'%f');
    m = m(:)'; % return as a row
end