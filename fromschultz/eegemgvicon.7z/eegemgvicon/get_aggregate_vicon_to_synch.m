function [movesToSynch,trials,casMoves,numGoodTrials] = get_aggregate_vicon_to_synch(cMoveInfo,skippedTrials)
% get_aggregate_vicon_to_synch.m - takes cell from first move file and
% outputs vectors need for synching first motion to EEG and EMG sets.
% 
% INPUTS
% cMoveInfo - cell read from index_first_moves.csv
% 
% OUTPUTS
% movesToSynch - col vector of first motion relative to synch pulse in vicon data
% trials - col vector of trial number
% casMoves - cas containing trial-by-trial move info
% numGoodTrials - col vector containing trials that were not skipped
% 
% EXAMPLE
% [movesToSynch,trials,casMoves,numGoodTrials] = get_aggregate_vicon_to_synch(cMoveInfo);

% Author - Krisanne Litinas
% $Id: get_aggregate_vicon_to_synch.m 5402 2010-06-11 20:23:21Z klitinas $

% Initialize vectors and cas
movesToSynch = [];
trials = [];
casMoves = {};
numGoodTrials = [];

% Loop through all trials
for i = 1:length(cMoveInfo)
    strLine = cMoveInfo{i};
    
    % Check for header line
    if ~isempty(findstr(strLine,'trial')) || isempty(strLine)
        movesToSynch(i) = nan;
        trials(i) = nan;
        casMoves{i} = nan;
        numGoodTrials(i) = nan;
        continue
    end
    
    [iMoveRelToSynch,numTrial,strMove,numTrialGood] = eevgetfirstmovesynch(strLine,skippedTrials);
    
    % Append 
    movesToSynch(i) = iMoveRelToSynch;
    trials(i) = numTrial;
    casMoves{i} = strMove;
    
    if ~isempty(numTrialGood) % good trial
        numGoodTrials(i) = numTrialGood;
    else % skipped trial
        numGoodTrials(i) = nan;
    end
    
end
movesToSynch = movesToSynch(:);
trials = trials(:);
casMoves = casMoves(:);
numGoodTrials = numGoodTrials(:);