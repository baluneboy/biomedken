#! /usr/bin/env python
import re, sys, os

#theFilesFileLoc = '/home/jcox/Documents/out.txt'


#filefolderFile = open(theFilesFileLoc)

rootDir = ''
if len(sys.argv) < 2:
    rootDir = 'os.getcwd()'
else:
    rootDir = sys.argv[1]

theCodesFileLoc = ''
if len(sys.argv) < 3:
    raise Exception('Input Missing','Please enter a codes file.')
else:
    theCodesFileLoc = sys.argv[2]

codesFile = open(theCodesFileLoc,'r')
codesList = codesFile.readlines()
for i in range(len(codesList)):
    codesList[i] = codesList[i][:5]

codesList = list(set(codesList))


for root, dirs, files in os.walk(sys.argv[1]):
    for dir in dirs:
        for code in codesList:
            t =  re.search(code, dir)
            if t is not None:
                print os.path.join(root,dir)

    for file in files:
        for code in codesList:
            t =  re.search(code, file)
            if t is not None:
                print os.path.join(root,file)
