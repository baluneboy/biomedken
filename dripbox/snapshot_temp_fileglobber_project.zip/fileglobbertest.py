#!/usr/bin/env python
""" Unit test for fileglobber.py """

__author__ = "Ken Hrovat"
__version__ = "$Id: fileglobbertest.py 2104 2008-08-04 11:16:27Z khrovat $"
__copyright__ = "Copyright (c) 2008 Ken Hrovat"
__license__ = "Python"

import fileglobber
import unittest

class FileGlobberBadInput(unittest.TestCase):
    def testNonDir(self):
        """fileglobber.FileGlobberIterFiles should fail with non-dir input"""
        self.assertRaises(fileglobber.DoesNotExistError, fileglobber.FileGlobberIterFiles, basePath='')

#FileGlobberIterFiles(basePath='/Users/ken/Pictures', fileWild='*gh*.jpg', skipDirWildList=['therapy'])

if __name__ == "__main__":
    unittest.main()
