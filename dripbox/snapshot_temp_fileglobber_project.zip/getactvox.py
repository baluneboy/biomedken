#!/usr/bin/env python

r""" getactvox - gather active voxel spreadsheets

Look along say these dirs & others (actually parent of /home/Uber/data/upper/fmri/fmri_local):

/home/Uber/data/upper/fmri/fmri_local/s1332plas_post/study_20071219/series_5_bas_MoCoSeries/roi/
/home/Uber/data/upper/fmri/fmri_local/s1332plas_post/study_20071219/series_9_bas_MoCoSeries/roi_notnorm/

to gather files like:

s1332plas_post_shoulder_vastroke_activevoxels.csv
s1332plas_post_shoulder_vastrokenotnorm_activevoxels.csv
s1332plas_post_wrist_vastroke_activevoxels.csv
s1332plas_post_wrist_vastrokenotnorm_activevoxels.csv
s1332plas_pre_shoulder_vastroke_activevoxels.csv
s1332plas_pre_shoulder_vastrokenotnorm_activevoxels.csv
s1332plas_pre_wrist_vastroke_activevoxels.csv
s1332plas_pre_wrist_vastrokenotnorm_activevoxels.csv

EXAMPLES:
getactvox.py --path=/home/Uber/data/upper/fmri/fmri_local --remap=samba --subject=s1332plas --session=pre --id=vastroke wrist shoulder

"""

__author__ = "Ken Hrovat"
__version__ = "$Id: getactvox.py 2235 2008-09-12 12:18:14Z khrovat $"
__copyright__ = "Copyright (c) 2008 Ken Hrovat"
__license__ = "Python"

from fileglobber import *
import os, re, sys
import mglob
from os.path import join, abspath, isfile, isdir, exists, basename, dirname
import csv
import fileinput
import argparse

def remapPath(s,old,new):
    """ for stupid Windows stupid backslash GDMFMS"""
    n = "%s" % s.replace(old,new).replace('/','\\')
    return n

def getSessionFromFilename(f):
    # put example filename here
    pat = r'^[cs]\d{4}\w{4}S(?P<session>\d{3})R\d{2}.dat'
    c = re.compile(pat)
    m = c.match(f)
    if m is None:
        return ''
    else:
        return m.group('session')

#Define exceptions
class FmriSessionError(Exception): pass
class DoesNotExistError(FmriSessionError): pass

class FmriSession(FileGlobber):

    def __init__(self, *args, **kwargs):
        
        # Pop some unique keyword args (these get bundled in kwargs for
        # FmriSession, but not used for base class, FileGlobber)
        self.subject = kwargs.pop('subject')
        self.session = kwargs.pop('session')
        self.task = kwargs.pop('task')
        self.id = kwargs.pop('id')
        
        # Set wildcard for activevoxels csv files
        # (like s1332plas_post_shoulder_vastroke_activevoxels.csv)
        kwargs['skipDirWildList'] = []
        kwargs['fileWild'] = self.subject + '_' + self.session + '_' + self.task + '_' + self.id + '_activevoxels.csv'

        # The heavy-lifting initialization
        FileGlobber.__init__(self, *args, **kwargs)
    
    def getFileList(self):
        return self.fileList
    
def getArgs():
    """ argument parser """
   
    # create the parser    
    parser = argparse.ArgumentParser(description='Concatenate activevoxels.csv files.')

    # add the arguments    
    parser.add_argument(
        '--remap',
        type=str,
        help='optional remap path (default: /home/Uber/data to s:\data)')
    
    parser.add_argument(
        '--path',
        type=str,
        help='optional path (default: present working directory)')
    
    parser.add_argument(
        '--subject',
        type=str,
        required=True,
        help='subject (like: s1332plas or c1316plas)')
    
    parser.add_argument(
        '--session',
        type=str,
        required=True,
        help='session (like: pre or control)')

    parser.add_argument(
        'tasks',
        type=str,
        nargs='+',
        help='one or more tasks to be considered')

    parser.add_argument(
        '--id',
        type=str,
        required=True,
        help='id (like: vastroke or vastrokenotnorm)')
    
    parser.add_argument(
        '--log',
        type=argparse.FileType('w'),
        default=sys.stdout,
        help='the file where to write this info '
             '(default: write to stdout)')
    
    # parse the command line    
    args = parser.parse_args()
        
    return args

if __name__ == '__main__':

    # create parser object, add args
    args = getArgs()
    remap = args.remap
    path = args.path
    subject = args.subject
    session = args.session
    id = args.id
    tasks = args.tasks

    # prepare the path (if none)
    if path is None:
        path = join(os.environ.get('FMRIPATH'),'fmri_local')
    
    # get predictable task path
    subjectSessionPath = join(path, subject + '_' + session)

    # remap (if necessary)
    if remap is None:
        pass
    elif remap.lower() == 'samba':
        oldPath = '/home/Uber/data'
        newPath = 's:\\data'
        subjectSessionPath = remapPath(subjectSessionPath,oldPath,newPath)
    else:
        oldPath,newPath = remap.split(',')
        subjectSessionPath = remapPath(subjectSessionPath,oldPath,newPath)

    # for each session, append these: # line, real lines, # line, imag lines
    fileList = []
    for task in tasks:
        thisTask = FmriSession(basePath=subjectSessionPath, subject=subject, session=session, task=task, id=id)
        for f in thisTask.fileList:
            fileList.append(f)

    # build an output string
    txt = ''

    # first file includes header line
    f1 = fileList.pop(0)
    fid = open(f1, "r")
    strin = fid.read()
    fid.close()
    txt += '%s' % strin

    # the rest of the files now...
    for f in fileList:
        fid = open(f, "r")
        strin = fid.read()
        fid.close()
        # skip first (header) line
        lines = strin.split('\n')
        lines.pop(0)
        for line in lines:
            txt += '%s\n' % line
 
    # write text
    args.log.write('%s' % txt)
    args.log.close()
