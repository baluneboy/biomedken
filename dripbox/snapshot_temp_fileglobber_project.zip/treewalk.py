import fnmatch
import os
 
rootPath = 'c:\\temp\\trashdir'
pattern = '*.mp3' # Can include any UNIX shell-style wildcards

for root, dirs, files in os.walk(rootPath):
    for filename in files:
        if fnmatch.fnmatch(filename, pattern):
            print os.path.join(root, filename)
        else:
            print "   " + os.path.join(root, filename)