#!/usr/bin/env python

import sys, os

#Define exceptions
class EveryotherError(Exception): pass
class OutOfRangeError(EveryotherError): pass
class NotIntegerError(EveryotherError): pass

class EveryOther(list):
	def __init__(self, n, b):
		self.b = b
		self.n = n
		if int(n) <> n: raise NotIntegerError, "input must be positive integer"
		if n < 1: raise OutOfRangeError, "input must be positive integer"
		list.__init__(self, range(b, n+1, 2))
	def __repr__(self):
		return "<type 'EveryOther' list of everyother, positive integers up to %d>" % self.n
	def __str__(self):
		s = "[ "
		for i in self:
			s += '%d ' % i
		s += "]"
		return s

class Odds(EveryOther):
	def __init__(self, n):
		EveryOther.__init__(self, n, 1)
	def __repr__(self):
		return "<type 'Odds' list of ODD, positive integers up to %d>" % self.n	
	def getLastSquare(self):
		return self[-1]**2
	def showLastSquare(self):
		print "Square of last value is %d" % self.getLastSquare()

class Evens(EveryOther):
	def __init__(self, n):
		EveryOther.__init__(self, n, 2)
	def __repr__(self):
		return "<type 'Evens' list of EVEN, positive integers up to %d>" % self.n

if __name__== '__main__':
	x = Odds(11)
	print x
	y = Evens(12)
	print y
	x