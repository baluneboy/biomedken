#!/usr/bin/env python

#py grep command
#sample command: grep("^x",dir())
#syntax: grep(regexp_string,list_of_strings_to_search)

import re

def grepBrute(string,list):
    expr = re.compile(string)
    for text in list:
        match = expr.search(text)
        if match != None:
            print match.string

# Two alternate solutions, courtesy of Gene H
# These are more elegant, and more detailed descriptions can be found here:
# http://www.faqs.org/docs/diveintopython/apihelper_filter.html
# http://www.faqs.org/docs/diveintopython/regression_filter.html

def grepExact(string,list):
    expr = re.compile(string)
    return [elem for elem in list if expr.match(elem)]

def grepAny(string,list):
    expr = re.compile(string)
    return filter(expr.search,list)

# Note a subtle difference between the above two:
# because the first uses expr.match(), it will only return exact matches
# while the latter will return a list containing strings that contain the
# search string in any position
# e.g.:
# list = ['normalize','size','nonzero','zenith']
# grepBrute('ze',list)
# grepExact one returns: ['zenith']
# grepAny one returns: ['normalize','size','nonzero','zenith']

def grepFile(string,filename):
    f = open(filename,'r')
    flist = f.readlines()
    f.close()
    list = [line.strip() for line in flist]
    return grepAny(string,list)

def hasString(string,filename):
    m = grepFile(string,filename)
    if len(m) == 0:
        return False
    else:
        return True
    
if __name__ == '__main__':
    #list = ['normalize','size','nonzero','zenith'];
    #print grepBrute('ze',list)
    #print grepExact('ze',list)
    #print grepAny('ze',list)
    string = '(targrad).*21$'
    filename = '/home/Uber/data/upper/serob/therapist/s1328plas/eval/20080325_Tue/chase_pro_145503.dat'
    if hasString(string,filename):
        print "found match"
    else:
        print "NO match"   