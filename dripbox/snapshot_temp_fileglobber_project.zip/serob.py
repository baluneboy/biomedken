#!/usr/bin/env python

r"""

serob.py class definitions for serob game dat files

Serob                           
    OneSlotSummary                       
            .basePath               
            .fileWildList               
            .totalFilesFound                
            .totalFilesSkipped                
            .totalFilesExpected             
                                .trial      
                                        .timestamp
                                        .numTrialFiles
                                        .fileList
    OtherGamesSummary
            .basePath               
            .fileWildList               
            .totalFilesFound                
            .totalFilesSkipped                
            .totalFilesExpected               
                                .trial      
                                        .timestamp
                                        .numTrialFiles
                                        .fileList

"""

import sys, os
import argparse
from fileglobber import *
import vastar_game


def getArgs(description):
    """ return an input argument parser object """
 
     # create the parser    
    parser = argparse.ArgumentParser(description=description)
    parser.add_argument('--basePath',type=str,required=True,help='basePath')
    parser.add_argument('--fileWild',type=str,help='optional fileWild')
    parser.add_argument('--log',type=argparse.FileType('w'),default=sys.stdout,
        help='the file where the configuration should be written '
             '(default: write the configuration to stdout)')
    
    # parse the command line    
    args = parser.parse_args()
    return args


def isOneSlotSummaryDir(basePath):
    " boolean true if basePath has at least 25 one_slot_*.dat files"
    fg = FileGlobber(basePath=basePath,fileWild='one_slot_*.dat')
    if len(fg.fileList) > 25:
        return True
    return False


class Serob(object):
    "an eval directory's dat file info container"

    def __init__(self, basePath=os.getcwd()):
        if not os.path.isdir(basePath):
            raise DoesNotExistError, "basePath %s does NOT exist" % basePath
        else:
            self.basePath = basePath
            self.evalType = self.getEvalType()
    
    def getEvalType(self):
        if isOneSlotSummaryDir(self.basePath):
            return OneSlotSummary(basePath=self.basePath)
        return OtherGamesSummary(basePath=self.basePath)


class EvalType(object):
    "a summary of eval directory's dat files"
    
    def __init__(self, basePath=os.getcwd()):
        self.basePath = basePath
        self.type = self.__class__.__name__
        self.fileWildList = []
    
    def showDatFiles(self):
        for fw in self.fileWildList:
            fg = FileGlobber(basePath=self.basePath,fileWild=fw)
            for f in fg.fileList:
                print f
            
    def __str__(self):
        c = self.__class__.__name__
        s = '%s' % c
        return s


class OneSlotSummary(EvalType):
    "a summary of eval directory's one_slot dat files"
    
    def __init__(self, *args, **kwargs):
        EvalType.__init__(self, *args, **kwargs)
        self.type = self.__class__.__name__
        self.fileWildList = ['one_slot_*.dat']


class SerobGame(object):
    "a serob game container"
    
    def __init__(self, basePath=os.getcwd(), fileWild=None):
        self.name = self.__class__.__name__
        self.basePath = basePath
        self.fileWild = fileWild

    def __str__(self):
        c = self.__class__.__name__
        s = '%s' % c
        return s
    
    
class OtherGamesSummary(EvalType):
    "a summary of eval directory's other game dat files"
    
    def __init__(self, *args, **kwargs):
        EvalType.__init__(self, *args, **kwargs)
        self.type = self.__class__.__name__
        self.fileWildList = ['point_to_point_*.dat','playback_rec_*.dat']

    
if __name__ == '__main__':
    
    # create parser object, add args
    args = getArgs('Get serob dat files.')
    
    # verify path
    if args.basePath is None:
        strMsg = 'MISSING PATH\nUSAGE: gather_serob_datfiles.py --basePath S:\data\upper\serob\therapist\s1351plas\eval\20080522_Thu'
        raise IOError(strMsg)
    s = Serob(basePath=args.basePath)
    print "%s dat files in %s" % (str(s.evalType), s.basePath)
    s.evalType.showDatFiles()