#!/usr/bin/env python

r""" fileglobber - a few useful classes (including iterators) for hunting down
                   files like say chase_rob*.dat
"""

__author__ = "Ken Hrovat"
__version__ = "$Id: fileglobber.py 5117 2010-04-20 11:46:38Z khrovat $"

import subprocess
import argparse
import warnings
import os, re, sys
from os.path import join, abspath, isfile, isdir, exists, basename, dirname

with warnings.catch_warnings():
        warnings.simplefilter("ignore",DeprecationWarning)
        import mglob

#Define exceptions
class FileGlobberError(Exception): pass
class DoesNotExistError(FileGlobberError): pass
class NotIntegerError(FileGlobberError): pass

class FileGlobber(object):
    """ FileGlobber class for recursive find of fileWild below basePath
        serves as base class for iterator classes
    """    

    def __init__(self, basePath=os.getcwd(), fileWild='chase_rob*.dat', skipDirWildList=['therapy','test','skipped']):
        if not isdir(basePath):
            raise DoesNotExistError, "basePath %s does NOT exist" % basePath
        else:
            self.basePath = abspath(basePath)
            
        self.fileWild = fileWild
        self.skipDirWildList = skipDirWildList
        self.fileList = self.globIt()
        self.uniqueDirList = self.getUniqueDirs()

    def __str__(self):
        c = self.__class__.__name__
        s = '\n%s (%d files, %d uniqueDirs)' % (c, len(self.fileList), len(self.uniqueDirList))
        s += "\n ........ basePath = '%s'" % self.basePath
        s += "\n ........ fileWild = '%s'" % self.fileWild
        s += "\n . skipDirWildList = ["
        for i in self.skipDirWildList:
            s += " '%s'," % i
        if s[-1] == ',':
            s = s[0:-1]
        s += ' ]'
        return s
    
    def globIt(self):
        """ the crux does recursive fileWild search starting at basePath while
            ignoring directories matching skipDirWildList
            
            !.svn/ !.hg/ !*_Data/ rec:.
               will skip .svn, .hg, foo_Data dirs (and their subdirs) in recurse
               and hey, the trailing / is the key ( \ does not work! )
        """
        cmd = ''
        for i in self.skipDirWildList:
            cmd += '!%s/ ' % i
        cmd += "rec:" + self.basePath + "=" + self.fileWild
        files = mglob.expand(cmd)
        files.sort()
        return files
    
    def getUniqueDirs(self):
        udList = list(set([dirname(f) for f in self.fileList]))
        udList.sort()
        return udList

class FileGlobberIter(FileGlobber):
    
    def __init__(self, *args, **kwargs):
        FileGlobber.__init__(self, *args, **kwargs)
        self.current = 0
        self.last = 0

    def __str__(self):
        s = FileGlobber.__str__(self)
        return s
    
    def __iter__(self):
        return self

class FileGlobberIterFiles(FileGlobberIter):
    
    def __init__(self, *args, **kwargs):
        FileGlobberIter.__init__(self, *args, **kwargs)
        self.last = len(self.fileList)
    
    def next(self):
        if self.current == self.last:
            raise StopIteration
        else:
            thisFile = self.fileList[self.current]
            self.current += 1
            return thisFile

class DicomGlobberIterFiles(FileGlobberIterFiles):
    
    def next(self):
        if self.current > 0:
            raise StopIteration
        else:
            thisFile = self.fileList[self.current]
            self.current += 1
            return thisFile        
        
class FileGlobberIterUniqDirs(FileGlobberIter):
    
    def __init__(self, *args, **kwargs):
        FileGlobberIter.__init__(self, *args, **kwargs)
        self.last = len(self.uniqueDirList)
    
    def next(self):
        if self.current == self.last:
            raise StopIteration
        else:
            thisDir = self.uniqueDirList[self.current]
            self.current += 1
            return thisDir

def getTimestampFile(f):
    """ return string with time stamp of file """
    import time
    stat_info=os.lstat(f) # get all the file info
    ts = stat_info.st_mtime
    time_fmt = "%Y-%m-%d"
    time_str = time.strftime(time_fmt, time.gmtime(ts))
    return time_str

def touchFile(f,ymd):
    p = subprocess.call(r"c:\cygwin\bin\touch.exe -d " + ymd + " " + f, shell=True)

def getArgs(description):
    """ return an input argument parser object """
 
     # create the parser    
    parser = argparse.ArgumentParser(description=description)
    parser.add_argument('--basePath',type=str,required=True,help='basePath')
    parser.add_argument('--fileWild',type=str,help='optional fileWild')
    parser.add_argument('--log',type=argparse.FileType('w'),default=sys.stdout,
        help='the file where the configuration should be written '
             '(default: write the configuration to stdout)')
    
    # parse the command line    
    args = parser.parse_args()
    return args

if __name__ == '__main__':
    
    #f = r"c:\temp\trash99.txt"
    #ymd = "2008-07-06"
    #touchFile(f,ymd)
    #sys.exit(0)
    
    # create parser object, add args
    args = getArgs('general fileglobber')
    basePath = args.basePath
    fileWild = args.fileWild
    
    # if path is none, then use cwd
    if basePath is None:
        basePath = os.getcwd()
    
    # if fileWild is none, then use '*01.img'
    if fileWild is None:
        fileWild = '*01.img'
    
    shoulderMatFiles = FileGlobberIterFiles(basePath=basePath, fileWild=fileWild)
    for f in shoulderMatFiles:
        print f
    sys.exit(0)
    
    udirs = FileGlobberIterUniqDirs(basePath=basePath, fileWild=fileWild, skipDirWildList=['*_ran*'])
    for d in udirs:
        #print d
        dgif = DicomGlobberIterFiles(basePath=d, fileWild=fileWild, skipDirWildList=['DO_NOT_USE*','*_OLD','used_for_printing_dc1'])
        for f in dgif:
            fNoExt = os.path.splitext(f)[0]
            ymd = getTimestampFile(fNoExt)
            dcmFiles = FileGlobberIterFiles(basePath=d, fileWild=fileWild, skipDirWildList=['DO_NOT_USE*','*_OLD','used_for_printing_dc1'])
            print "apply " + ymd + " timestamp to these files "
            for dcm in dcmFiles:
                touchFile(dcm,ymd)
                print dcm
    sys.exit(0)

    #files = FileGlobberIterFiles(basePath=basePath, fileWild=fileWild, skipDirWildList=['DO_NOT_USE*','*_OLD','used_for_printing_dc1'])
    #files = FileGlobberIterFiles(basePath='S:\\data\\upper\\clinical_measures\\plas', fileWild='AMAT*.xls', skipDirWildList=['DO_NOT_USE*','*_OLD','used_for_printing_dc1'])
    #files = FileGlobberIterFiles(basePath='/media/GREEN/sampledata/upper/bci/therapy/s1801bcis/the_task', fileWild='s1801*.dat', skipDirWildList=['DO_NOT_USE*','*_OLD','used_for_printing_dc1'])
    #print files
    for f in files:
        print f
