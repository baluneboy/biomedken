#!/usr/bin/env python
import os
for root, dirs, files in os.walk('/tmp'):
	for file in [f for f in files if f.endswith(".txt")]:
		print file
