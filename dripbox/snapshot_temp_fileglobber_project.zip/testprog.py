#!/usr/bin/env python

import argparse

parser = argparse.ArgumentParser(description='Match path pattern(s).')
parser.add_argument('globPattern', type=str, nargs=1, help='a glob pattern for pattern matching')

args = parser.parse_args()
print(args)

if __name__ == '__main__':
    wildPath = sys.argv[1]
    nargs = len(sys.argv) - 1
    if nargs == 1:
        print "simpleglob", 
    elif nargs == 2:
        print "regex filter simpleglob results", 
    elif nargs == 3:
        print "chained regex filters on simpleglob", 
    else:
        raise InputError("Did not expect %d input arguments." % nargs) 
        
    print wildPath, nargs
    sys.exit(0)