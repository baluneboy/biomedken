#!/usr/bin/env python

def average(values):
    """Computes the arithmetic mean of a list of numbers.

    >>> print average([20, 31, 70])
    40.0
    
    >>> print average([2, 3, 7])
    4.0    
    """
    return sum(values, 0.0) / len(values)

import doctest
doctest.testmod()   # automatically validate the embedded tests