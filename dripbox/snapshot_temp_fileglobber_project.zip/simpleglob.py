#!/usr/bin/env python

import glob, sys

if __name__ == '__main__':
	wildPath = sys.argv[1]
	results = glob.glob(wildPath)
	for i in results:
		print i
	sys.exit(0)