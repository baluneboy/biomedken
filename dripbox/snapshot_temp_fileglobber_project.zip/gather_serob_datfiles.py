#!/usr/bin/env python

import sys
from os.path import basename
import argparse
import vastar_game

def getArgs(description):
    """ return an input argument parser object """
   
    # create the parser    
    parser = argparse.ArgumentParser(description=description)
    parser.add_argument('--basePath',type=str,required=True,help='basePath')
    parser.add_argument('--fileWild',type=str,help='optional fileWild')
    parser.add_argument('--log',type=argparse.FileType('w'),default=sys.stdout,
        help='the file where the configuration should be written '
             '(default: write the configuration to stdout)')
    
    # parse the command line    
    args = parser.parse_args()
    return args

if __name__ == '__main__':
    
    # create parser object, add args
    args = getArgs('Get serob dat files.')
    
    # verify path
    if args.basePath is None:
        strMsg = 'MISSING PATH\nUSAGE: gather_serob_datfiles.py --basePath S:\data\upper\serob\therapist\s1351plas\eval\20080522_Thu'
        raise IOError(strMsg)
    print 'Searching in basePath ', args.basePath
    
    # a nice game delimiter
    DELIM = '~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~'
    
    # get chase_rob files (these need more interpretaion work than others)
    fileWild = 'chase_rob_*.dat'
    chaseRobFileIterObj = vastar_game.ChaseRobIterFiles(basePath=args.basePath,fileWild=fileWild)
    print '%s\nFound these %d %s files:' % (DELIM,len(chaseRobFileIterObj.fileList),fileWild)    
    for f in chaseRobFileIterObj:
        print basename(f)
        
    # get point_to_point, playback_rec and round_dyn files
    gameList = ['point_to_point_*.dat','playback_rec_*.dat','round_dyn_*.dat']
    for fileWild in gameList:
        vaIterFiles = vastar_game.VaStarGameIterFiles(basePath=args.basePath,fileWild=fileWild)
        print '%s\nFound these %d %s files:' % (DELIM,len(vaIterFiles.fileList),fileWild)
        for f in vaIterFiles:
            print basename(f)
    
    # get playback_static files, which have unique naming convention and don't have directional breakdown
    fileWild = 'playback_static_*.dat'
    playbackStaticFileIterObj = vastar_game.PlaybackStaticIterFiles(basePath=args.basePath,fileWild=fileWild)
    print '%s\nFound these %d %s files:' % (DELIM,len(playbackStaticFileIterObj.fileList),fileWild)
    for f in playbackStaticFileIterObj:
        print basename(f)

    # circle
    fileWild = 'circle_*.dat'
    circleFileIterObj = vastar_game.CircleIterFiles(basePath=args.basePath,fileWild=fileWild)
    print '%s\nFound these %d %s files:' % (DELIM,len(circleFileIterObj.fileList),fileWild)
    for f in circleFileIterObj:
        print basename(f)
        
    # 3 non-moving digates_rob
    fileWild = 'digates_rob_*.dat'
    nonMovingDigatesRobFileIterObj = vastar_game.NonMovingDigatesRobIterFiles3(basePath=args.basePath,fileWild=fileWild)
    print '%s\nFound these three-non-moving %d %s files:' % (DELIM,len(nonMovingDigatesRobFileIterObj.fileList),fileWild)
    for f in nonMovingDigatesRobFileIterObj:
        print basename(f)

    # 5 non-moving digates_rob
    fileWild = 'digates_rob_*.dat'
    nonMovingDigatesRobFileIterObj = vastar_game.NonMovingDigatesRobIterFiles5(basePath=args.basePath,fileWild=fileWild)
    print '%s\nFound these five-non-moving %d %s files:' % (DELIM,len(nonMovingDigatesRobFileIterObj.fileList),fileWild)
    for f in nonMovingDigatesRobFileIterObj:
        print basename(f)

    # 7 non-moving digates_rob
    fileWild = 'digates_rob_*.dat'
    nonMovingDigatesRobFileIterObj = vastar_game.NonMovingDigatesRobIterFiles7(basePath=args.basePath,fileWild=fileWild)
    print '%s\nFound these five-non-moving %d %s files:' % (DELIM,len(nonMovingDigatesRobFileIterObj.fileList),fileWild)
    for f in nonMovingDigatesRobFileIterObj:
        print basename(f)
                
    # moving digates_rob
    fileWild = 'digates_rob_*.dat'
    movingDigatesRobFileIterObj = vastar_game.MovingDigatesRobIterFiles(basePath=args.basePath,fileWild=fileWild)
    print '%s\nFound these moving %d %s files:' % (DELIM,len(movingDigatesRobFileIterObj.fileList),fileWild)
    for f in movingDigatesRobFileIterObj:
        print basename(f)