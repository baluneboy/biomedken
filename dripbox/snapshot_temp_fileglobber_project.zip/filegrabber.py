#!/usr/bin/env python

import win32clipboard as w 
#import win32con

def getClipText(): 
    w.OpenClipboard() 
    d=w.GetClipboardData(w.CF_TEXT) 
    w.CloseClipboard() 
    return d 
 
def setClipText(aType,aString): 
    w.OpenClipboard()
    w.EmptyClipboard()
    w.SetClipboardData(aType,aString) 
    w.CloseClipboard()
    
if __name__ == '__main__':
    s = getClipText();
    print s
    s += 'per'
    setClipText(w.CF_TEXT,s)
