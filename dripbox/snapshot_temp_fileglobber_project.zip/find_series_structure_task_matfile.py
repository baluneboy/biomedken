#!/usr/bin/env python

from fileglobber import getArgs, FileGlobberIterFiles
import sys

if __name__ == '__main__':
    
    # create parser object, add args
    args = getArgs('general fileglobber')
    basePath = args.basePath
    fileWild = args.fileWild
    
    matFiles = FileGlobberIterFiles(basePath=basePath, fileWild=fileWild)
    for f in matFiles:
        print f
    sys.exit(0)