#!/usr/bin/env python
"""Unit test for everyother.py

This program was inspired by part of "Dive Into Python".
"""

__author__ = "Ken Hrovat"
__version__ = "$Id: everyothertest.py 2131 2008-08-12 10:49:34Z khrovat $"
__copyright__ = "Copyright (c) 2008 Ken Hrovat"
__license__ = "Python"

import everyother
import unittest

class KnownValues(unittest.TestCase):
    knownValueOdds = ( \
			(1, [1]),
			(2, [1]),
			(3, [1,3]),
			(8, [1,3,5,7]),
			(9, [1,3,5,7,9]),
			(10,[1,3,5,7,9]))

    knownValueEvens = ( \
			(1, []),
			(2, [2]),
			(3, [2]),
			(8, [2,4,6,8]),
			(9, [2,4,6,8]),
			(10,[2,4,6,8,10]))

    def testKnownValueOdds(self):
        """everyother.Odds  should give known list output with known integer input"""
        for integer, theList in self.knownValueOdds:
            result = everyother.Odds(integer)
            self.assertEqual(theList, result)

    def testKnownValueEvens(self):
        """everyother.Evens should give known list output with known integer input"""
        for integer, theList in self.knownValueEvens:
            result = everyother.Evens(integer)
            self.assertEqual(theList, result)

class EveryotherBadInput(unittest.TestCase):
    def testZero(self):
        """everyother should fail with 0 input"""
        self.assertRaises(everyother.OutOfRangeError, everyother.Odds, 0)
        self.assertRaises(everyother.OutOfRangeError, everyother.Evens, 0)

    def testNegative(self):
        """everyother should fail with negative input"""
        self.assertRaises(everyother.OutOfRangeError, everyother.Odds, -1)
        self.assertRaises(everyother.OutOfRangeError, everyother.Evens, -1)

    def testNonInteger(self):
        """everyother should fail with non-integer input"""
        self.assertRaises(everyother.NotIntegerError, everyother.Odds, 0.5)
        self.assertRaises(everyother.NotIntegerError, everyother.Evens, 0.5)

if __name__ == "__main__":
    unittest.main()
