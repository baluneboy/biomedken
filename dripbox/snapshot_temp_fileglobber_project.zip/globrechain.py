#!/usr/bin/env python

import glob, sys, argparse

class Error(Exception):
    """Base class for exceptions in this module."""
    pass

class InputError(Error):
    """Exception raised for errors in the input."""
    def __init__(self, msg):
        self.msg = msg
    def __str__(self):
        return repr(self.msg)

def parseArgs(argv):
    """Parse arguments (string patterns to match)."""
    parser = argparse.ArgumentParser(description='Glob-and-match patterns.')
    parser.add_argument('globPattern', metavar='globPattern', type=str,
                       help='is a glob pattern string to be matched')
    parser.add_argument('regexPatterns', metavar='regexPattern', type=str, nargs='*',
                       help='is a pattern string to be matched')
    return parser.parse_args()
   
if __name__ == '__main__':
    args = parseArgs(sys.argv)
    print "FIRST GLOB THIS: " + args.globPattern
    for pat in args.regexPatterns:
        print "THEN REGEX THIS: " + pat    
    sys.exit(0)